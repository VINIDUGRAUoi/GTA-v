# Open City — jogo 3D de mundo aberto (Godot 4)

Projeto original inspirado no gênero de mundo aberto. Não usa mapas, marcas,
personagens nem recursos de nenhum jogo existente.

**Estado atual: Etapas 1 a 3 + versão inicial da Etapa 5.**
Todo o código foi escrito, mas **ainda não foi executado** (o ambiente onde foi
gerado não tem o Godot). Veja `docs/REGISTRO.md`.

## Como abrir e executar
1. Instale o **Godot 4.3 ou superior** (versão "standard", sem .NET): https://godotengine.org/download
2. No gerenciador de projetos, clique em **Importar** e escolha o arquivo `project.godot`.
3. Abra o projeto uma vez no editor (ele gera o cache de scripts) e aperte **F5**.
4. Se aparecer algum erro no painel "Saída/Depurador", copie e me envie: corrijo na próxima etapa.

## Controles (registrados em `scripts/core/input_setup.gd`)
| Ação | Teclado/Mouse | Gamepad |
|---|---|---|
| Mover | W A S D / setas | Analógico esquerdo |
| Câmera | Mouse | Analógico direito |
| Correr | Shift | Clique no analógico esquerdo |
| Pular | Espaço | A |
| Agachar (segurar) | C / Ctrl | B |
| Interagir | E | X |
| Liberar/capturar mouse | Esc (ou clique na janela) | Start |
| Dano de teste (-10 vida) | K | — |

Para mudar uma tecla, edite `KEY_BINDINGS` no `input_setup.gd`. O menu de
configuração de controles entra na Etapa 8.

## Testes automatizados
```
godot --headless --path . -s tests/run_tests.gd
```
Verifica ações de entrada, vida/cura/morte do jogador e geração determinística do mundo.

## Requisitos mínimos (alvo)
- Godot 4.3+, GPU com OpenGL 3.3 (renderizador "Compatibility", escolhido por rodar em hardware modesto).
- 4 GB de RAM. Para visuais melhores no futuro, dá para migrar para o renderizador "Forward+" em Configurações do Projeto.

## Dependências externas
Nenhuma além do Godot. Todos os visuais são **placeholders geométricos**; sem texturas, modelos, sons ou músicas.

## Estrutura
Veja `docs/ARQUITETURA.md`.
