extends RefCounted
## Geometria procedural: triângulos com normal, UV e cor por vértice, usando SurfaceTool.
## A ordem dos vértices é corrigida automaticamente (no Godot a frente é o sentido horário).

static func new_st() -> SurfaceTool:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_meta("n", 0)
    return st


static func has_data(st: SurfaceTool) -> bool:
    return int(st.get_meta("n", 0)) > 0


static func _v(st: SurfaceTool, p: Vector3, n: Vector3, uv: Vector2, color: Color) -> void:
    st.set_color(color)
    st.set_normal(n)
    st.set_uv(uv)
    st.add_vertex(p)


static func _count(st: SurfaceTool) -> void:
    st.set_meta("n", int(st.get_meta("n", 0)) + 1)


static func _emit(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, n: Vector3, uva: Vector2, uvb: Vector2, uvc: Vector2, color: Color) -> void:
    var cr := (b - a).cross(c - a)
    if cr.length_squared() < 1e-12:
        return
    if cr.dot(n) > 0.0:
        var tp := b
        b = c
        c = tp
        var tu := uvb
        uvb = uvc
        uvc = tu
    _v(st, a, n, uva, color)
    _v(st, b, n, uvb, color)
    _v(st, c, n, uvc, color)
    _count(st)


static func tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, hint: Vector3, color: Color = Color.WHITE, uva: Vector2 = Vector2.ZERO, uvb: Vector2 = Vector2.ZERO, uvc: Vector2 = Vector2.ZERO) -> void:
    var n := (b - a).cross(c - a)
    if n.length_squared() < 1e-12:
        return
    n = n.normalized()
    if n.dot(hint) < 0.0:
        n = -n
    _emit(st, a, b, c, n, uva, uvb, uvc, color)


static func quad(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, hint: Vector3, color: Color = Color.WHITE, uv0: Vector2 = Vector2(0, 0), uv1: Vector2 = Vector2(1, 0), uv2: Vector2 = Vector2(1, 1), uv3: Vector2 = Vector2(0, 1)) -> void:
    var n := (p1 - p0).cross(p2 - p0) + (p2 - p0).cross(p3 - p0)
    if n.length_squared() < 1e-12:
        return
    n = n.normalized()
    if n.dot(hint) < 0.0:
        n = -n
    _emit(st, p0, p1, p2, n, uv0, uv1, uv2, color)
    _emit(st, p0, p2, p3, n, uv0, uv2, uv3, color)


static func _emit_smooth(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, color: Color, hint: Vector3) -> void:
    var cr := (b - a).cross(c - a)
    if cr.length_squared() < 1e-12:
        return
    if cr.dot(hint) > 0.0:
        var tp := b
        b = c
        c = tp
        var tn := nb
        nb = nc
        nc = tn
    _v(st, a, na, Vector2.ZERO, color)
    _v(st, b, nb, Vector2.ZERO, color)
    _v(st, c, nc, Vector2.ZERO, color)
    _count(st)


static func quad_smooth(st: SurfaceTool, ps: Array, ns: Array, color: Color, hint: Vector3) -> void:
    var p0: Vector3 = ps[0]
    var p1: Vector3 = ps[1]
    var p2: Vector3 = ps[2]
    var p3: Vector3 = ps[3]
    var n0: Vector3 = ns[0]
    var n1: Vector3 = ns[1]
    var n2: Vector3 = ns[2]
    var n3: Vector3 = ns[3]
    _emit_smooth(st, p0, p1, p2, n0, n1, n2, color, hint)
    _emit_smooth(st, p0, p2, p3, n0, n2, n3, color, hint)


## Caixa com UV em metros. `base` = centro da base. v_origin = altura (y) onde a borda
## de baixo da textura encosta. tile = tamanho (m) de uma repetição da textura.
static func box(st: SurfaceTool, base: Vector3, size: Vector3, tile: Vector2, v_origin: float, color: Color, sides: bool = true, top: bool = true, bottom: bool = true) -> void:
    var x0 := base.x - size.x * 0.5
    var x1 := base.x + size.x * 0.5
    var z0 := base.z - size.z * 0.5
    var z1 := base.z + size.z * 0.5
    var y0 := base.y
    var y1 := base.y + size.y
    var v0 := (v_origin - y0) / tile.y
    var v1 := (v_origin - y1) / tile.y
    if sides:
        var ux := size.x / tile.x
        var uz := size.z / tile.x
        quad(st, Vector3(x0, y0, z1), Vector3(x1, y0, z1), Vector3(x1, y1, z1), Vector3(x0, y1, z1), Vector3(0, 0, 1), color, Vector2(0, v0), Vector2(ux, v0), Vector2(ux, v1), Vector2(0, v1))
        quad(st, Vector3(x1, y0, z0), Vector3(x0, y0, z0), Vector3(x0, y1, z0), Vector3(x1, y1, z0), Vector3(0, 0, -1), color, Vector2(0, v0), Vector2(ux, v0), Vector2(ux, v1), Vector2(0, v1))
        quad(st, Vector3(x1, y0, z1), Vector3(x1, y0, z0), Vector3(x1, y1, z0), Vector3(x1, y1, z1), Vector3(1, 0, 0), color, Vector2(0, v0), Vector2(uz, v0), Vector2(uz, v1), Vector2(0, v1))
        quad(st, Vector3(x0, y0, z0), Vector3(x0, y0, z1), Vector3(x0, y1, z1), Vector3(x0, y1, z0), Vector3(-1, 0, 0), color, Vector2(0, v0), Vector2(uz, v0), Vector2(uz, v1), Vector2(0, v1))
    if top:
        quad(st, Vector3(x0, y1, z1), Vector3(x1, y1, z1), Vector3(x1, y1, z0), Vector3(x0, y1, z0), Vector3.UP, color, Vector2(x0, z1) / tile.x, Vector2(x1, z1) / tile.x, Vector2(x1, z0) / tile.x, Vector2(x0, z0) / tile.x)
    if bottom:
        quad(st, Vector3(x0, y0, z0), Vector3(x1, y0, z0), Vector3(x1, y0, z1), Vector3(x0, y0, z1), Vector3.DOWN, color)


## Quadrilátero horizontal com UV em metros (u = x / tile, v = z / tile).
static func flat_quad(st: SurfaceTool, x0: float, z0: float, x1: float, z1: float, y: float, tile: float, color: Color) -> void:
    quad(st, Vector3(x0, y, z1), Vector3(x1, y, z1), Vector3(x1, y, z0), Vector3(x0, y, z0), Vector3.UP, color,
        Vector2(x0, z1) / tile, Vector2(x1, z1) / tile, Vector2(x1, z0) / tile, Vector2(x0, z0) / tile)


static func top_quad(st: SurfaceTool, cx: float, cz: float, w: float, d: float, y: float, tile: float, color: Color) -> void:
    flat_quad(st, cx - w * 0.5, cz - d * 0.5, cx + w * 0.5, cz + d * 0.5, y, tile, color)


static func cylinder(st: SurfaceTool, base: Vector3, r0: float, r1: float, height: float, segs: int, color: Color, caps: bool = true) -> void:
    var up := Vector3(0.0, height, 0.0)
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        var d0 := Vector3(cos(a0), 0.0, sin(a0))
        var d1 := Vector3(cos(a1), 0.0, sin(a1))
        quad_smooth(st, [base + d0 * r0, base + d1 * r0, base + up + d1 * r1, base + up + d0 * r1], [d0, d1, d1, d0], color, d0 + d1)
        if caps:
            tri(st, base, base + d1 * r0, base + d0 * r0, Vector3.DOWN, color)
            tri(st, base + up, base + up + d0 * r1, base + up + d1 * r1, Vector3.UP, color)


static func _sph(c: Vector3, r: float, scl: Vector3, t: float, p: float) -> Vector3:
    return c + Vector3(sin(t) * cos(p) * scl.x, cos(t) * scl.y, sin(t) * sin(p) * scl.z) * r


static func _sph_n(scl: Vector3, t: float, p: float) -> Vector3:
    return Vector3(sin(t) * cos(p) / scl.x, cos(t) / scl.y, sin(t) * sin(p) / scl.z).normalized()


static func sphere(st: SurfaceTool, center: Vector3, radius: float, rings: int, segs: int, color: Color, scl: Vector3 = Vector3.ONE, theta_max: float = PI) -> void:
    for r in rings:
        var t0 := theta_max * float(r) / float(rings)
        var t1 := theta_max * float(r + 1) / float(rings)
        for s in segs:
            var p0 := TAU * float(s) / float(segs)
            var p1 := TAU * float(s + 1) / float(segs)
            var pts := [_sph(center, radius, scl, t0, p0), _sph(center, radius, scl, t0, p1), _sph(center, radius, scl, t1, p1), _sph(center, radius, scl, t1, p0)]
            var nrm := [_sph_n(scl, t0, p0), _sph_n(scl, t0, p1), _sph_n(scl, t1, p1), _sph_n(scl, t1, p0)]
            var mid: Vector3 = (pts[0] + pts[2]) * 0.5 - center
            quad_smooth(st, pts, nrm, color, mid)


static func cone(st: SurfaceTool, base: Vector3, radius: float, height: float, segs: int, color: Color) -> void:
    var apex := base + Vector3(0.0, height, 0.0)
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        var d0 := Vector3(cos(a0), 0.0, sin(a0))
        var d1 := Vector3(cos(a1), 0.0, sin(a1))
        tri(st, base + d0 * radius, base + d1 * radius, apex, d0 + d1 + Vector3.UP * 0.5, color)


## Disco no plano YZ (usado em rodas e caixas de roda). side = +1 ou -1 (lado visível).
static func disc_x(st: SurfaceTool, center: Vector3, radius: float, segs: int, side: float, color: Color) -> void:
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        tri(st, center, center + Vector3(0.0, cos(a0), sin(a0)) * radius, center + Vector3(0.0, cos(a1), sin(a1)) * radius, Vector3(side, 0, 0), color)


static func ring_x(st: SurfaceTool, x: float, r_in: float, r_out: float, segs: int, side: float, color: Color) -> void:
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        quad(st, Vector3(x, cos(a0) * r_in, sin(a0) * r_in), Vector3(x, cos(a0) * r_out, sin(a0) * r_out),
            Vector3(x, cos(a1) * r_out, sin(a1) * r_out), Vector3(x, cos(a1) * r_in, sin(a1) * r_in), Vector3(side, 0, 0), color)


static func tread_x(st: SurfaceTool, xa: float, xb: float, r: float, segs: int, color: Color) -> void:
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        quad(st, Vector3(xa, cos(a0) * r, sin(a0) * r), Vector3(xb, cos(a0) * r, sin(a0) * r),
            Vector3(xb, cos(a1) * r, sin(a1) * r), Vector3(xa, cos(a1) * r, sin(a1) * r),
            Vector3(0.0, cos((a0 + a1) * 0.5), sin((a0 + a1) * 0.5)), color)


## Seção de um "loft" (carroceria): retângulo em z com meia-largura hw e alturas y0..y1.
static func loft_segment(a: Dictionary, b: Dictionary, st_top: Variant, st_bottom: Variant, st_side: Variant) -> void:
    var ax: float = a.get("cx", 0.0)
    var bx: float = b.get("cx", 0.0)
    var alt := Vector3(ax - float(a["hw"]), a["y1"], a["z"])
    var art := Vector3(ax + float(a["hw"]), a["y1"], a["z"])
    var alb := Vector3(ax - float(a["hw"]), a["y0"], a["z"])
    var arb := Vector3(ax + float(a["hw"]), a["y0"], a["z"])
    var blt := Vector3(bx - float(b["hw"]), b["y1"], b["z"])
    var brt := Vector3(bx + float(b["hw"]), b["y1"], b["z"])
    var blb := Vector3(bx - float(b["hw"]), b["y0"], b["z"])
    var brb := Vector3(bx + float(b["hw"]), b["y0"], b["z"])
    if st_top != null:
        quad(st_top, alt, art, brt, blt, Vector3.UP)
    if st_bottom != null:
        quad(st_bottom, alb, arb, brb, blb, Vector3.DOWN)
    if st_side != null:
        quad(st_side, alb, alt, blt, blb, Vector3.LEFT)
        quad(st_side, arb, art, brt, brb, Vector3.RIGHT)


static func loft_cap(st: SurfaceTool, s: Dictionary, forward: float) -> void:
    var cx: float = s.get("cx", 0.0)
    quad(st, Vector3(cx - float(s["hw"]), s["y0"], s["z"]), Vector3(cx + float(s["hw"]), s["y0"], s["z"]),
        Vector3(cx + float(s["hw"]), s["y1"], s["z"]), Vector3(cx - float(s["hw"]), s["y1"], s["z"]), Vector3(0, 0, forward))


static func loft_all(st: SurfaceTool, secs: Array) -> void:
    for i in secs.size() - 1:
        loft_segment(secs[i], secs[i + 1], st, st, st)
    loft_cap(st, secs[0], -1.0)
    loft_cap(st, secs[secs.size() - 1], 1.0)
