extends Node
## Autoload "GameSettings": configurações de gráficos e jogabilidade, salvas em
## user://settings.cfg. Outros sistemas leem os valores e escutam o sinal `changed`.

signal changed

const PATH := "user://settings.cfg"
const PRESETS := {
    "baixa": {"shadows": false, "msaa": 0, "view_distance": 150.0, "ped_count": 8, "traffic_count": 5},
    "media": {"shadows": true, "msaa": 0, "view_distance": 250.0, "ped_count": 18, "traffic_count": 10},
    "alta": {"shadows": true, "msaa": 2, "view_distance": 400.0, "ped_count": 30, "traffic_count": 16},
}
const KEYS := ["quality", "shadows", "msaa", "view_distance", "ped_count", "traffic_count", "fov", "sensitivity", "max_fps", "show_fps"]

var quality := "media"
var shadows := true
var msaa := 0 # 0 = desligado, 2 = 2x, 4 = 4x
var view_distance := 250.0
var ped_count := 18
var traffic_count := 10
var fov := 75.0
var sensitivity := 1.0
var max_fps := 60 # 0 = sem limite
var show_fps := true


func _ready() -> void:
    _apply_preset_values("baixa" if OS.has_feature("mobile") else "media")
    load_settings()
    apply()


func apply_preset(preset_name: String) -> void:
    _apply_preset_values(preset_name)
    apply()


func _apply_preset_values(preset_name: String) -> void:
    if not PRESETS.has(preset_name):
        return
    quality = preset_name
    var preset: Dictionary = PRESETS[preset_name]
    for key: String in preset:
        set(key, preset[key])


func apply() -> void:
    Engine.max_fps = max_fps
    var viewport := get_viewport()
    if viewport != null:
        match msaa:
            2:
                viewport.msaa_3d = Viewport.MSAA_2X
            4:
                viewport.msaa_3d = Viewport.MSAA_4X
            _:
                viewport.msaa_3d = Viewport.MSAA_DISABLED
    changed.emit()


func save_settings() -> void:
    var cfg := ConfigFile.new()
    for key: String in KEYS:
        cfg.set_value("settings", key, get(key))
    cfg.save(PATH)


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return
    for key: String in KEYS:
        if cfg.has_section_key("settings", key):
            var value: Variant = cfg.get_value("settings", key)
            if typeof(value) == typeof(get(key)):
                set(key, value)
