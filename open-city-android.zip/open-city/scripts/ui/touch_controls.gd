extends Control
## Controles de toque (Android): analógico virtual flutuante na metade esquerda,
## arrastar na direita para girar a câmera e quatro botões. Tudo é desenhado em
## código (sem texturas). Envia InputEventAction, então o jogador não precisa
## saber se a entrada veio do toque, do teclado ou do gamepad.

signal look_dragged(relative: Vector2)

const STICK_RADIUS := 90.0
const DEADZONE := 0.15

var _stick_id := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _look_id := -1
var _held := {} # índice do dedo -> nome do botão/ação


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    get_viewport().size_changed.connect(queue_redraw)


func _buttons() -> Dictionary:
    var s := get_viewport_rect().size
    return {
        "jump": {"pos": Vector2(s.x - 110.0, s.y - 130.0), "r": 60.0, "label": "Pular"},
        "interact": {"pos": Vector2(s.x - 260.0, s.y - 90.0), "r": 45.0, "label": "Usar"},
        "crouch": {"pos": Vector2(s.x - 260.0, s.y - 200.0), "r": 45.0, "label": "Agachar"},
        "sprint": {"pos": Vector2(s.x - 110.0, s.y - 270.0), "r": 45.0, "label": "Correr"},
    }


func _button_at(pos: Vector2) -> String:
    var buttons := _buttons()
    for name: String in buttons:
        var b: Dictionary = buttons[name]
        if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.2:
            return name
    return ""


func _input(event: InputEvent) -> void:
    var touch := event as InputEventScreenTouch
    if touch != null:
        if touch.pressed:
            _on_press(touch.index, touch.position)
        else:
            _on_release(touch.index)
        return
    var drag := event as InputEventScreenDrag
    if drag != null:
        _on_drag(drag.index, drag.position, drag.relative)


func _on_press(index: int, pos: Vector2) -> void:
    var name := _button_at(pos)
    if name != "":
        _held[index] = name
        _send(name, true, 1.0)
    elif pos.x < get_viewport_rect().size.x * 0.45 and _stick_id == -1:
        _stick_id = index
        _stick_origin = pos
        _stick_pos = pos
    elif _look_id == -1:
        _look_id = index
    queue_redraw()


func _on_release(index: int) -> void:
    if _held.has(index):
        _send(_held[index], false, 0.0)
        _held.erase(index)
    if index == _stick_id:
        _stick_id = -1
        _update_stick(Vector2.ZERO)
    if index == _look_id:
        _look_id = -1
    queue_redraw()


func _on_drag(index: int, pos: Vector2, relative: Vector2) -> void:
    if index == _stick_id:
        _stick_pos = pos
        var v := (_stick_pos - _stick_origin) / STICK_RADIUS
        if v.length() > 1.0:
            v = v.normalized()
        if v.length() < DEADZONE:
            v = Vector2.ZERO
        _update_stick(v)
        queue_redraw()
    elif index == _look_id:
        look_dragged.emit(relative)


func _update_stick(v: Vector2) -> void:
    _send("move_right", v.x > 0.0, maxf(v.x, 0.0))
    _send("move_left", v.x < 0.0, maxf(-v.x, 0.0))
    _send("move_back", v.y > 0.0, maxf(v.y, 0.0))
    _send("move_forward", v.y < 0.0, maxf(-v.y, 0.0))


func _send(action: String, pressed: bool, strength: float) -> void:
    if not InputMap.has_action(action):
        return
    var ev := InputEventAction.new()
    ev.action = action
    ev.pressed = pressed
    ev.strength = strength if pressed else 0.0
    Input.parse_input_event(ev)


func _draw() -> void:
    var font := ThemeDB.fallback_font
    var buttons := _buttons()
    for name: String in buttons:
        var b: Dictionary = buttons[name]
        var active := _held.values().has(name)
        var fill := Color(1, 1, 1, 0.35 if active else 0.15)
        draw_circle(b["pos"], b["r"], fill)
        draw_arc(b["pos"], b["r"], 0.0, TAU, 32, Color(1, 1, 1, 0.6), 2.0)
        draw_string(font, b["pos"] + Vector2(-b["r"], 6.0), b["label"], HORIZONTAL_ALIGNMENT_CENTER, b["r"] * 2.0, 16)
    if _stick_id != -1:
        draw_circle(_stick_origin, STICK_RADIUS, Color(1, 1, 1, 0.12))
        draw_arc(_stick_origin, STICK_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 2.0)
        var offset := (_stick_pos - _stick_origin).limit_length(STICK_RADIUS)
        draw_circle(_stick_origin + offset, 35.0, Color(1, 1, 1, 0.45))
