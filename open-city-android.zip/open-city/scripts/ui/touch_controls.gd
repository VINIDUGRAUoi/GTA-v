extends Control
## Controles de toque (Android). A pé: analógico flutuante na metade esquerda, arrastar na
## direita para girar a câmera, botões Pular/Correr/Agachar/Usar. Dentro de um veículo
## o layout muda: setas de direção, Acelerar, Freio, Freio de mão e Sair. Tudo é desenhado
## em código e envia InputEventAction (o jogo não distingue toque, teclado ou gamepad).

signal look_dragged(relative: Vector2)

const STICK_RADIUS := 90.0
const DEADZONE := 0.15

var _driving := false
var _stick_id := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _look_id := -1
var _held := {} # índice do dedo -> nome do botão


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    get_viewport().size_changed.connect(queue_redraw)


## Troca o layout (a pé / dirigindo).
func set_driving(value: bool) -> void:
    if value == _driving:
        return
    reset_state()
    _driving = value
    queue_redraw()


func _notification(what: int) -> void:
    # Ao pausar/despausar, os "soltar dedo" se perdem: zera tudo para não ficar andando sozinho.
    if what == NOTIFICATION_PAUSED or what == NOTIFICATION_UNPAUSED:
        reset_state()


func reset_state() -> void:
    var layout := _buttons()
    for index in _held.keys():
        var name: String = _held[index]
        if layout.has(name):
            _send(layout[name]["action"], false, 0.0)
    _held.clear()
    if _stick_id != -1:
        _update_stick(Vector2.ZERO)
    _stick_id = -1
    _look_id = -1
    queue_redraw()


func _buttons() -> Dictionary:
    var s := get_viewport_rect().size
    var b := {
        "map": {"action": "map", "pos": Vector2(s.x - 60.0, 50.0), "r": 34.0, "label": "Mapa"},
        "pause": {"action": "pause", "pos": Vector2(s.x - 150.0, 50.0), "r": 34.0, "label": "Menu"},
    }
    if _driving:
        b["steer_left"] = {"action": "move_left", "pos": Vector2(110.0, s.y - 110.0), "r": 62.0, "icon": "left"}
        b["steer_right"] = {"action": "move_right", "pos": Vector2(290.0, s.y - 110.0), "r": 62.0, "icon": "right"}
        b["gas"] = {"action": "move_forward", "pos": Vector2(s.x - 110.0, s.y - 140.0), "r": 72.0, "label": "Acelerar"}
        b["brake"] = {"action": "move_back", "pos": Vector2(s.x - 270.0, s.y - 100.0), "r": 54.0, "label": "Freio"}
        b["handbrake"] = {"action": "jump", "pos": Vector2(s.x - 110.0, s.y - 290.0), "r": 42.0, "label": "F. mão"}
        b["exit"] = {"action": "interact", "pos": Vector2(s.x - 270.0, s.y - 220.0), "r": 42.0, "label": "Sair"}
    else:
        b["jump"] = {"action": "jump", "pos": Vector2(s.x - 110.0, s.y - 130.0), "r": 60.0, "label": "Pular"}
        b["interact"] = {"action": "interact", "pos": Vector2(s.x - 260.0, s.y - 90.0), "r": 45.0, "label": "Usar"}
        b["crouch"] = {"action": "crouch", "pos": Vector2(s.x - 260.0, s.y - 200.0), "r": 45.0, "label": "Agachar"}
        b["sprint"] = {"action": "sprint", "pos": Vector2(s.x - 110.0, s.y - 270.0), "r": 45.0, "label": "Correr"}
    return b


func _button_at(pos: Vector2) -> String:
    var layout := _buttons()
    for name: String in layout:
        var b: Dictionary = layout[name]
        if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.2:
            return name
    return ""


func _input(event: InputEvent) -> void:
    var touch := event as InputEventScreenTouch
    if touch != null:
        if touch.pressed:
            _on_press(touch.index, touch.position)
        else:
            _on_release(touch.index)
        return
    var drag := event as InputEventScreenDrag
    if drag != null:
        _on_drag(drag.index, drag.position, drag.relative)


func _on_press(index: int, pos: Vector2) -> void:
    var name := _button_at(pos)
    if name != "":
        _held[index] = name
        _send(_buttons()[name]["action"], true, 1.0)
    elif not _driving and pos.x < get_viewport_rect().size.x * 0.45 and _stick_id == -1:
        _stick_id = index
        _stick_origin = pos
        _stick_pos = pos
    elif _look_id == -1:
        _look_id = index
    queue_redraw()


func _on_release(index: int) -> void:
    if _held.has(index):
        var layout := _buttons()
        var name: String = _held[index]
        if layout.has(name):
            _send(layout[name]["action"], false, 0.0)
        _held.erase(index)
    if index == _stick_id:
        _stick_id = -1
        _update_stick(Vector2.ZERO)
    if index == _look_id:
        _look_id = -1
    queue_redraw()


func _on_drag(index: int, pos: Vector2, relative: Vector2) -> void:
    if index == _stick_id:
        _stick_pos = pos
        var v := (_stick_pos - _stick_origin) / STICK_RADIUS
        if v.length() > 1.0:
            v = v.normalized()
        if v.length() < DEADZONE:
            v = Vector2.ZERO
        _update_stick(v)
        queue_redraw()
    elif index == _look_id:
        look_dragged.emit(relative)


func _update_stick(v: Vector2) -> void:
    _send("move_right", v.x > 0.0, maxf(v.x, 0.0))
    _send("move_left", v.x < 0.0, maxf(-v.x, 0.0))
    _send("move_back", v.y > 0.0, maxf(v.y, 0.0))
    _send("move_forward", v.y < 0.0, maxf(-v.y, 0.0))


func _send(action: String, pressed: bool, strength: float) -> void:
    if not InputMap.has_action(action):
        return
    var ev := InputEventAction.new()
    ev.action = action
    ev.pressed = pressed
    ev.strength = strength if pressed else 0.0
    Input.parse_input_event(ev)


func _draw() -> void:
    var font := ThemeDB.fallback_font
    var layout := _buttons()
    var active := _held.values()
    for name: String in layout:
        var b: Dictionary = layout[name]
        var pos: Vector2 = b["pos"]
        var r: float = b["r"]
        draw_circle(pos, r, Color(1, 1, 1, 0.35 if active.has(name) else 0.15))
        draw_arc(pos, r, 0.0, TAU, 32, Color(1, 1, 1, 0.6), 2.0)
        if b.has("icon"):
            var dir := -1.0 if b["icon"] == "left" else 1.0
            var a := Vector2(dir * r * 0.4, 0.0)
            var c1 := Vector2(-dir * r * 0.3, -r * 0.4)
            var c2 := Vector2(-dir * r * 0.3, r * 0.4)
            draw_colored_polygon(PackedVector2Array([pos + a, pos + c1, pos + c2]), Color(1, 1, 1, 0.8))
        else:
            draw_string(font, pos + Vector2(-r, 6.0), b["label"], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 16)
    if _stick_id != -1:
        draw_circle(_stick_origin, STICK_RADIUS, Color(1, 1, 1, 0.12))
        draw_arc(_stick_origin, STICK_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 2.0)
        var offset := (_stick_pos - _stick_origin).limit_length(STICK_RADIUS)
        draw_circle(_stick_origin + offset, 35.0, Color(1, 1, 1, 0.45))
