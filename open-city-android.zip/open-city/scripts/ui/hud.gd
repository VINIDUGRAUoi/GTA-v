extends CanvasLayer
## HUD mínimo (Etapa 3): vida, resistência, FPS e dicas de controle.
## Recebe dados do jogador por sinais; não lê o jogador diretamente.

var touch_mode := false

var _health_bar: ProgressBar
var _stamina_bar: ProgressBar
var _info: Label


func _ready() -> void:
    var box := VBoxContainer.new()
    box.position = Vector2(16.0, 16.0)
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(box)
    _health_bar = _make_row(box, "Vida", Color(0.85, 0.2, 0.2))
    _stamina_bar = _make_row(box, "Fôlego", Color(0.2, 0.7, 0.9))

    _info = Label.new()
    _info.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _info.position = Vector2(16.0, 80.0)
    add_child(_info)


func _process(_delta: float) -> void:
    if touch_mode:
        _info.text = "FPS: %d" % Engine.get_frames_per_second()
        return
    _info.text = "FPS: %d\nWASD mover | Shift correr | Espaço pular | C agachar\nMouse/analógico direito: câmera | E interagir | K dano (teste) | Esc libera o mouse" % Engine.get_frames_per_second()


func set_health(current: float, maximum: float) -> void:
    _set_bar(_health_bar, current, maximum)


func set_stamina(current: float, maximum: float) -> void:
    _set_bar(_stamina_bar, current, maximum)


func _set_bar(bar: ProgressBar, current: float, maximum: float) -> void:
    if bar == null:
        return
    bar.max_value = maxf(maximum, 1.0)
    bar.value = clampf(current, 0.0, bar.max_value)


func _make_row(parent: Control, title: String, color: Color) -> ProgressBar:
    var row := HBoxContainer.new()
    row.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(row)

    var label := Label.new()
    label.text = title
    label.custom_minimum_size = Vector2(70.0, 0.0)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    row.add_child(label)

    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(220.0, 18.0)
    bar.show_percentage = false
    bar.max_value = 100.0
    bar.value = 100.0
    bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var fill := StyleBoxFlat.new()
    fill.bg_color = color
    bar.add_theme_stylebox_override("fill", fill)
    row.add_child(bar)
    return bar
