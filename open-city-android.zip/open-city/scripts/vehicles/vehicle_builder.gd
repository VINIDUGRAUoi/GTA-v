extends RefCounted
## Monta o visual (caixas coloridas = PLACEHOLDER) e as colisões de um veículo.
## Usado tanto pelo veículo dirigível quanto pelo carro do trânsito.


static func wheel_positions(data: Dictionary) -> Array:
    var size: Vector3 = data["size"]
    var x := size.x * 0.5 - 0.1
    var z := size.z * 0.5 - 0.7
    return [Vector3(-x, -0.3, -z), Vector3(x, -0.3, -z), Vector3(-x, -0.3, z), Vector3(x, -0.3, z)]


static func build(root: Node3D, data: Dictionary, color: Color, wheel_meshes: bool) -> Dictionary:
    var size: Vector3 = data["size"]
    var cabin: Vector3 = data["cabin"]
    var cabin_z: float = data["cabin_z"]

    var body_mat := _material(color, 0.4, 0.3)
    var glass_mat := _material(Color(0.08, 0.12, 0.18), 0.1, 0.0)
    var tail_mat := _material(Color(0.4, 0.0, 0.0), 0.5, 0.0)
    tail_mat.emission_enabled = true
    tail_mat.emission = Color(1.0, 0.0, 0.0)
    tail_mat.emission_energy_multiplier = 0.4
    var head_mat := _material(Color(1.0, 1.0, 0.8), 0.3, 0.0)
    head_mat.emission_enabled = true
    head_mat.emission = Color(1.0, 1.0, 0.8)
    head_mat.emission_energy_multiplier = 1.0

    var cabin_pos := Vector3(0.0, size.y * 0.5 + cabin.y * 0.5, cabin_z)
    _add_box(root, size, Vector3.ZERO, body_mat)
    _add_box(root, cabin, cabin_pos, glass_mat)
    _add_collider(root, size, Vector3.ZERO)
    _add_collider(root, cabin, cabin_pos)

    var lamp_x := size.x * 0.5 - 0.3
    for sx in [-1.0, 1.0]:
        _add_box(root, Vector3(0.3, 0.15, 0.05), Vector3(sx * lamp_x, 0.05, -size.z * 0.5), head_mat)
        _add_box(root, Vector3(0.3, 0.15, 0.05), Vector3(sx * lamp_x, 0.05, size.z * 0.5), tail_mat)

    if wheel_meshes:
        var wheel_mat := _material(Color(0.05, 0.05, 0.05), 0.9, 0.0)
        var radius: float = data["wheel_radius"]
        for p: Vector3 in wheel_positions(data):
            var mesh := MeshInstance3D.new()
            var cyl := CylinderMesh.new()
            cyl.top_radius = radius
            cyl.bottom_radius = radius
            cyl.height = 0.3
            mesh.mesh = cyl
            mesh.material_override = wheel_mat
            mesh.rotation_degrees.z = 90.0
            mesh.position = Vector3(p.x, -0.5, p.z)
            root.add_child(mesh)

    return {"body_mat": body_mat, "tail_mat": tail_mat}


static func _material(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = roughness
    mat.metallic = metallic
    return mat


static func _add_box(root: Node3D, size: Vector3, pos: Vector3, mat: Material) -> void:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.material_override = mat
    mesh.position = pos
    root.add_child(mesh)


static func _add_collider(root: Node3D, size: Vector3, pos: Vector3) -> void:
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = size
    shape.shape = box
    shape.position = pos
    root.add_child(shape)
