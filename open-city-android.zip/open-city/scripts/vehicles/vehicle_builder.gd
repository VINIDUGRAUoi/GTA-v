extends RefCounted
## Monta carros "low-poly" detalhados em código: carroceria afunilada (capô, para-brisa
## inclinado, vidros, porta-malas), faróis, lanternas, grade, para-choques, placas,
## retrovisores, frestas das portas, caixas de roda e rodas com aro e raios.
## O mesmo mesh serve para todos os veículos do mesmo tipo; só a pintura muda.

const GeoScript := preload("res://scripts/core/geo.gd")

static var _cache := {}
static var _shared := {}
static var _wheel_cache := {}


static func wheel_positions(data: Dictionary) -> Array:
    var size: Vector3 = data["size"]
    var x := size.x * 0.5 - 0.1
    var z := size.z * 0.5 - 0.7
    return [Vector3(-x, -0.3, -z), Vector3(x, -0.3, -z), Vector3(-x, -0.3, z), Vector3(x, -0.3, z)]


static func _shared_material(mat_name: String) -> StandardMaterial3D:
    if _shared.has(mat_name):
        return _shared[mat_name]
    var m := StandardMaterial3D.new()
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    match mat_name:
        "glass":
            m.albedo_color = Color(0.05, 0.08, 0.12)
            m.metallic = 0.7
            m.roughness = 0.08
        "trim":
            m.albedo_color = Color(0.04, 0.04, 0.045)
            m.roughness = 0.6
        "head":
            m.albedo_color = Color(1.0, 1.0, 0.85)
            m.emission_enabled = true
            m.emission = Color(1.0, 0.95, 0.8)
            m.emission_energy_multiplier = 1.2
        "plate":
            m.albedo_color = Color(0.92, 0.92, 0.9)
        "cargo":
            m.albedo_color = Color(0.88, 0.88, 0.9)
            m.roughness = 0.6
        "decal":
            m.vertex_color_use_as_albedo = true
            m.roughness = 0.5
        "light_r":
            m.albedo_color = Color(1.0, 0.1, 0.1)
            m.emission_enabled = true
            m.emission = Color(1.0, 0.05, 0.05)
            m.emission_energy_multiplier = 2.0
        "light_b":
            m.albedo_color = Color(0.2, 0.3, 1.0)
            m.emission_enabled = true
            m.emission = Color(0.1, 0.2, 1.0)
            m.emission_energy_multiplier = 2.0
        "wheel":
            m.vertex_color_use_as_albedo = true
            m.roughness = 0.7
            m.metallic = 0.25
    _shared[mat_name] = m
    return m


static func _paint_material(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.3
    m.metallic = 0.5
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m


static func _tail_material() -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.4, 0.0, 0.0)
    m.emission_enabled = true
    m.emission = Color(1.0, 0.0, 0.0)
    m.emission_energy_multiplier = 0.4
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m


## flip = true: a frente do modelo fica em +Z (veículo dirigível, física do Godot).
## wheel_meshes = true: junta as rodas à malha (carros do trânsito e estacionados).
static func build(root: Node3D, data: Dictionary, color: Color, wheel_meshes: bool, flip: bool = false) -> Dictionary:
    var key := str(data["name"]) + ("|rodas" if wheel_meshes else "")
    if not _cache.has(key):
        _cache[key] = _build_mesh(data, wheel_meshes)
    var entry: Dictionary = _cache[key]
    var body_mat := _paint_material(color)
    var tail_mat := _tail_material()

    var mi := MeshInstance3D.new()
    mi.mesh = entry["mesh"]
    if flip:
        mi.rotation.y = PI
    if wheel_meshes:
        mi.visibility_range_end = 140.0
    var names: Array = entry["names"]
    for i in names.size():
        if names[i] == "paint":
            mi.set_surface_override_material(i, body_mat)
        elif names[i] == "tail":
            mi.set_surface_override_material(i, tail_mat)
    root.add_child(mi)

    var sgn := -1.0 if flip else 1.0
    var size: Vector3 = data["size"]
    var cabin: Vector3 = data["cabin"]
    var sill: float = data["sill"]
    var belt := sill + size.y * 0.97
    var cabin_z: float = float(data["cabin_z"]) * sgn
    _add_collider(root, size, Vector3(0.0, sill + size.y * 0.5, 0.0))
    _add_collider(root, cabin, Vector3(0.0, belt + cabin.y * 0.5, cabin_z))
    if data.get("cargo", false):
        var cz := float(data["cabin_z"]) + cabin.z * 0.5 + 0.1
        var cl := size.z * 0.5 - 0.1 - cz
        _add_collider(root, Vector3(size.x, 2.1, cl), Vector3(0.0, belt + 1.05, (cz + cl * 0.5) * sgn))
    return {"body_mat": body_mat, "tail_mat": tail_mat}


static func _add_collider(root: Node3D, size: Vector3, pos: Vector3) -> void:
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = size
    shape.shape = box
    shape.position = pos
    root.add_child(shape)


static func _wheel_cached(radius: float) -> ArrayMesh:
    var key := snappedf(radius, 0.01)
    if not _wheel_cache.has(key):
        _wheel_cache[key] = _wheel_mesh(radius)
    return _wheel_cache[key]


static func make_wheel(radius: float) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = _wheel_cached(radius)
    return mi


static func _wheel_mesh(r: float) -> ArrayMesh:
    var st := GeoScript.new_st()
    var hw := 0.12 + r * 0.12
    var tire := Color(0.04, 0.04, 0.045)
    var rim := Color(0.72, 0.72, 0.76)
    var dark := Color(0.12, 0.12, 0.14)
    var segs := 22
    GeoScript.tread_x(st, -hw, hw, r, segs, tire)
    for side: float in [-1.0, 1.0]:
        var x := hw * side
        GeoScript.ring_x(st, x, r * 0.72, r, segs, side, tire)
        GeoScript.ring_x(st, x + side * 0.004, r * 0.5, r * 0.72, segs, side, rim)
        GeoScript.disc_x(st, Vector3(x + side * 0.002, 0.0, 0.0), r * 0.5, segs, side, dark)
        for k in 5:
            var a := TAU * float(k) / 5.0
            var d0 := Vector3(0.0, cos(a), sin(a))
            var perp := Vector3(0.0, -sin(a), cos(a)) * (0.06 * r)
            var c := Vector3(x + side * 0.006, 0.0, 0.0)
            GeoScript.quad(st, c - perp, c + perp, c + perp + d0 * (r * 0.5), c - perp + d0 * (r * 0.5), Vector3(side, 0, 0), rim)
    var mesh := ArrayMesh.new()
    st.commit(mesh)
    mesh.surface_set_material(0, _shared_material("wheel"))
    return mesh


static func _box(st: SurfaceTool, base: Vector3, size: Vector3) -> void:
    GeoScript.box(st, base, size, Vector2.ONE, 0.0, Color.WHITE, true, true, true)


static func _blob(st: SurfaceTool, center: Vector3, radii: Vector3) -> void:
    GeoScript.sphere(st, center, 1.0, 4, 10, Color.WHITE, radii)


## Interpola as seções-chave com suavização, gerando mais seções (curvas suaves).
static func _resample(keys: Array, count: int) -> Array:
    var out: Array = []
    var last := keys.size() - 1
    for k in count:
        var kf := float(k) / float(count - 1) * float(last)
        var a := mini(floori(kf), last - 1)
        var t := smoothstep(0.0, 1.0, kf - float(a))
        var ka: Dictionary = keys[a]
        var kb: Dictionary = keys[a + 1]
        out.append({
            "z": lerpf(float(ka["z"]), float(kb["z"]), kf - float(a)),
            "hw": lerpf(float(ka["hw"]), float(kb["hw"]), t),
            "y0": lerpf(float(ka["y0"]), float(kb["y0"]), t),
            "y1": lerpf(float(ka["y1"]), float(kb["y1"]), t),
            "kf": kf,
        })
    return out


static func _build_mesh(data: Dictionary, with_wheels: bool) -> Dictionary:
    var sts := {}
    for n in ["paint", "glass", "trim", "head", "tail", "plate", "cargo", "decal", "light_r", "light_b"]:
        sts[n] = GeoScript.new_st()
    var paint: SurfaceTool = sts["paint"]
    var glass: SurfaceTool = sts["glass"]
    var trim: SurfaceTool = sts["trim"]
    var head: SurfaceTool = sts["head"]
    var tail: SurfaceTool = sts["tail"]
    var plate: SurfaceTool = sts["plate"]
    var cargo: SurfaceTool = sts["cargo"]

    var size: Vector3 = data["size"]
    var cabin: Vector3 = data["cabin"]
    var cz: float = data["cabin_z"]
    var sill: float = data["sill"]
    var w := size.x
    var h := size.y
    var l := size.z
    var z0 := -l * 0.5
    var z1 := l * 0.5
    var belt := sill + h * 0.97
    var is_box: bool = data.get("box", false)

    # ---- carroceria baixa (capô, laterais, porta-malas) com cantos arredondados
    var keys: Array = []
    if is_box:
        keys = [
            {"z": z0, "hw": w * 0.46, "y0": sill + 0.15, "y1": belt - 0.05},
            {"z": z0 + 0.2, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1 - 0.2, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1, "hw": w * 0.47, "y0": sill + 0.12, "y1": belt - 0.05},
        ]
    else:
        var hood := maxf(float(data.get("hood", 0.25)), 0.12)
        var trunk := maxf(float(data.get("trunk", 0.15)), 0.05)
        keys = [
            {"z": z0, "hw": w * 0.42, "y0": sill + 0.14, "y1": sill + h * 0.5},
            {"z": z0 + l * 0.04, "hw": w * 0.48, "y0": sill + 0.06, "y1": sill + h * 0.72},
            {"z": z0 + l * 0.12, "hw": w * 0.5, "y0": sill, "y1": sill + h * 0.86},
            {"z": z0 + l * hood, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1 - l * trunk, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1 - l * 0.04, "hw": w * 0.48, "y0": sill + 0.02, "y1": sill + h * 0.88},
            {"z": z1, "hw": w * 0.42, "y0": sill + 0.1, "y1": sill + h * 0.62},
        ]
    var body_secs := _resample(keys, 10 if is_box else 20)
    var body_power := 5.0 if is_box else 3.2
    var body_choose := func(_i: int, _s: int, _n: Vector3) -> Variant:
        return paint
    GeoScript.rounded_loft(body_choose, body_secs, 16, body_power, paint, paint)

    # ---- cabine: teto curvo, para-brisa e vidro traseiro inclinados, janelas laterais
    var cw := cabin.x
    var ch := cabin.y
    var cl := cabin.z
    var slope_f := minf(cl * 0.32, 0.8)
    var slope_r := minf(cl * 0.28, 0.7)
    if is_box:
        slope_f = minf(cl * 0.12, 0.4)
        slope_r = 0.0
    var cabin_keys: Array = [
        {"z": cz - cl * 0.5, "hw": cw * 0.485, "y0": belt - 0.06, "y1": belt + 0.04},
        {"z": cz - cl * 0.5 + slope_f, "hw": cw * 0.44, "y0": belt - 0.06, "y1": belt + ch},
        {"z": cz + cl * 0.5 - slope_r, "hw": cw * 0.44, "y0": belt - 0.06, "y1": belt + ch},
        {"z": cz + cl * 0.5, "hw": cw * 0.485, "y0": belt - 0.06, "y1": belt + (ch if is_box else 0.04)},
    ]
    var cabin_secs := _resample(cabin_keys, 16)
    var roof_end := 3.0 if is_box else 2.0
    var cabin_segs := 14
    var cabin_choose := func(i: int, s: int, _n: Vector3) -> Variant:
        var kf := (float(cabin_secs[i]["kf"]) + float(cabin_secs[i + 1]["kf"])) * 0.5
        var t := TAU * float(s) / float(cabin_segs)
        if sin(t) > 0.5 and kf >= 1.0 and kf < roof_end:
            return paint
        if sin(t) < -0.2:
            return paint
        return glass
    GeoScript.rounded_loft(cabin_choose, cabin_secs, cabin_segs, 3.6, glass, paint if is_box else glass)

    # coluna B
    for sx: float in [-1.0, 1.0]:
        _box(paint, Vector3(sx * (cw * 0.44 + 0.002), belt, cz), Vector3(0.05, ch * 0.9, 0.09))

    # ---- frente e traseira
    _blob(trim, Vector3(0.0, sill + 0.1, z0 + 0.04), Vector3(w * 0.46, 0.1, 0.1))
    _blob(trim, Vector3(0.0, sill + 0.1, z1 - 0.04), Vector3(w * 0.46, 0.1, 0.1))
    _blob(trim, Vector3(0.0, sill + h * 0.34, z0 + 0.02), Vector3(w * 0.2, h * 0.1, 0.04))
    for sx: float in [-1.0, 1.0]:
        _blob(head, Vector3(sx * w * 0.33, sill + h * 0.52, z0 + 0.06), Vector3(0.17, 0.06, 0.05))
        _blob(tail, Vector3(sx * w * 0.35, sill + h * 0.58, z1 - 0.06), Vector3(0.17, 0.06, 0.05))
    _box(plate, Vector3(0.0, sill + 0.06, z0 - 0.04), Vector3(0.5, 0.12, 0.02))
    _box(plate, Vector3(0.0, sill + 0.06, z1 + 0.04), Vector3(0.5, 0.12, 0.02))

    # ---- laterais: frestas das portas, maçanetas, retrovisores
    for sx: float in [-1.0, 1.0]:
        for k in [-0.1, 0.32]:
            _box(trim, Vector3(sx * (w * 0.5 + 0.004), sill + h * 0.08, cz + cl * float(k)), Vector3(0.014, h * 0.86, 0.014))
        _box(trim, Vector3(sx * (w * 0.5 + 0.006), belt - 0.14, cz + cl * 0.02), Vector3(0.012, 0.025, 0.14))
        _blob(paint, Vector3(sx * (cw * 0.5 + 0.1), belt + 0.1, cz - cl * 0.5 + 0.4), Vector3(0.05, 0.05, 0.09))

    # ---- caixas de roda
    var radius: float = data["wheel_radius"]
    for p: Vector3 in wheel_positions(data):
        var side := 1.0 if p.x > 0.0 else -1.0
        GeoScript.disc_x(trim, Vector3(side * (w * 0.5 + 0.004), -0.5, p.z), radius * 1.2, 16, side, Color.WHITE)

    if data.get("spoiler", false):
        _box(paint, Vector3(0.0, belt + 0.3, z1 - 0.35), Vector3(w * 0.85, 0.04, 0.28))
        for sx: float in [-1.0, 1.0]:
            _box(trim, Vector3(sx * w * 0.3, belt + 0.06, z1 - 0.35), Vector3(0.05, 0.24, 0.05))
    if data.get("bed", false):
        var zb := cz + cl * 0.5
        var len := z1 - zb
        for sx: float in [-1.0, 1.0]:
            _box(paint, Vector3(sx * (w * 0.5 - 0.03), belt, zb + len * 0.5), Vector3(0.06, 0.34, len))
        _box(paint, Vector3(0.0, belt, z1 - 0.03), Vector3(w, 0.34, 0.06))
        _box(paint, Vector3(0.0, belt, zb), Vector3(w - 0.1, 0.42, 0.06))
    if data.get("cargo", false):
        var zc := cz + cl * 0.5 + 0.1
        var clen := z1 - 0.1 - zc
        _box(cargo, Vector3(0.0, belt, zc + clen * 0.5), Vector3(w, 2.1, clen))
        _box(trim, Vector3(0.0, belt + 1.05, z1 - 0.1), Vector3(0.04, 2.0, 0.03))

    # ---- pintura especial (viatura, táxi, ambulância, ônibus)
    var decal: SurfaceTool = sts["decal"]
    var light_r: SurfaceTool = sts["light_r"]
    var light_b: SurfaceTool = sts["light_b"]
    var roof_y := belt + ch
    match str(data.get("livery", "")):
        "police":
            var black := Color(0.05, 0.05, 0.07)
            for sx: float in [-1.0, 1.0]:
                for dz: float in [-0.18, 0.18]:
                    GeoScript.box(decal, Vector3(sx * (w * 0.5 + 0.007), sill + h * 0.1, cz + cl * dz), Vector3(0.012, h * 0.72, cl * 0.32), Vector2.ONE, 0.0, black, true, true, true)
                GeoScript.box(decal, Vector3(sx * (w * 0.5 + 0.008), belt - 0.14, cz), Vector3(0.012, 0.05, l * 0.7), Vector2.ONE, 0.0, Color(0.1, 0.25, 0.65), true, true, true)
            _box(trim, Vector3(0.0, roof_y - 0.01, cz), Vector3(w * 0.5, 0.07, 0.22))
            _box(light_r, Vector3(-w * 0.12, roof_y + 0.05, cz), Vector3(0.2, 0.06, 0.2))
            _box(light_b, Vector3(w * 0.12, roof_y + 0.05, cz), Vector3(0.2, 0.06, 0.2))
        "taxi":
            _box(head, Vector3(0.0, roof_y, cz), Vector3(0.5, 0.14, 0.2))
        "ambulance":
            for sx: float in [-1.0, 1.0]:
                GeoScript.box(decal, Vector3(sx * (w * 0.5 + 0.007), sill + h * 0.3, cz), Vector3(0.012, 0.14, l * 0.88), Vector2.ONE, 0.0, Color(0.8, 0.08, 0.08), true, true, true)
                GeoScript.box(decal, Vector3(sx * (w * 0.5 + 0.009), sill + 0.08, cz - cl * 0.22), Vector3(0.012, 0.18, 0.5), Vector2.ONE, 0.0, Color(0.9, 0.1, 0.1), true, true, true)
            _box(light_r, Vector3(-0.3, roof_y, cz), Vector3(0.3, 0.08, 0.18))
            _box(light_b, Vector3(0.3, roof_y, cz), Vector3(0.3, 0.08, 0.18))
        "bus":
            for sx: float in [-1.0, 1.0]:
                GeoScript.box(decal, Vector3(sx * (w * 0.5 + 0.007), sill + 0.25, 0.0), Vector3(0.012, 0.18, l * 0.95), Vector2.ONE, 0.0, Color(0.8, 0.1, 0.1), true, true, true)
                GeoScript.box(decal, Vector3(sx * (w * 0.5 + 0.008), sill + 0.5, 0.0), Vector3(0.012, 0.05, l * 0.95), Vector2.ONE, 0.0, Color(0.1, 0.25, 0.65), true, true, true)

    var mesh := ArrayMesh.new()
    var names: Array = []
    for n: String in sts:
        var st: SurfaceTool = sts[n]
        if not GeoScript.has_data(st):
            continue
        st.commit(mesh)
        var idx := mesh.get_surface_count() - 1
        if n != "paint" and n != "tail":
            mesh.surface_set_material(idx, _shared_material(n))
        names.append(n)
    if with_wheels:
        var wst := SurfaceTool.new()
        wst.begin(Mesh.PRIMITIVE_TRIANGLES)
        var wmesh := _wheel_cached(radius)
        for p: Vector3 in wheel_positions(data):
            wst.append_from(wmesh, 0, Transform3D(Basis(), Vector3(p.x, -0.5, p.z)))
        wst.commit(mesh)
        mesh.surface_set_material(mesh.get_surface_count() - 1, _shared_material("wheel"))
        names.append("wheel")
    return {"mesh": mesh, "names": names}
