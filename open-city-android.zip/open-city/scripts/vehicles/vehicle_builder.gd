extends RefCounted
## Monta carros "low-poly" detalhados em código: carroceria afunilada (capô, para-brisa
## inclinado, vidros, porta-malas), faróis, lanternas, grade, para-choques, placas,
## retrovisores, frestas das portas, caixas de roda e rodas com aro e raios.
## O mesmo mesh serve para todos os veículos do mesmo tipo; só a pintura muda.

const GeoScript := preload("res://scripts/core/geo.gd")

static var _cache := {}
static var _shared := {}
static var _wheel_cache := {}


static func wheel_positions(data: Dictionary) -> Array:
    var size: Vector3 = data["size"]
    var x := size.x * 0.5 - 0.1
    var z := size.z * 0.5 - 0.7
    return [Vector3(-x, -0.3, -z), Vector3(x, -0.3, -z), Vector3(-x, -0.3, z), Vector3(x, -0.3, z)]


static func _shared_material(mat_name: String) -> StandardMaterial3D:
    if _shared.has(mat_name):
        return _shared[mat_name]
    var m := StandardMaterial3D.new()
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    match mat_name:
        "glass":
            m.albedo_color = Color(0.05, 0.08, 0.12)
            m.metallic = 0.7
            m.roughness = 0.08
        "trim":
            m.albedo_color = Color(0.04, 0.04, 0.045)
            m.roughness = 0.6
        "head":
            m.albedo_color = Color(1.0, 1.0, 0.85)
            m.emission_enabled = true
            m.emission = Color(1.0, 0.95, 0.8)
            m.emission_energy_multiplier = 1.2
        "plate":
            m.albedo_color = Color(0.92, 0.92, 0.9)
        "cargo":
            m.albedo_color = Color(0.88, 0.88, 0.9)
            m.roughness = 0.6
        "wheel":
            m.vertex_color_use_as_albedo = true
            m.roughness = 0.7
            m.metallic = 0.25
    _shared[mat_name] = m
    return m


static func _paint_material(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.3
    m.metallic = 0.5
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m


static func _tail_material() -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.4, 0.0, 0.0)
    m.emission_enabled = true
    m.emission = Color(1.0, 0.0, 0.0)
    m.emission_energy_multiplier = 0.4
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m


static func build(root: Node3D, data: Dictionary, color: Color, wheel_meshes: bool) -> Dictionary:
    var key := str(data["name"])
    if not _cache.has(key):
        _cache[key] = _build_mesh(data)
    var entry: Dictionary = _cache[key]
    var body_mat := _paint_material(color)
    var tail_mat := _tail_material()

    var mi := MeshInstance3D.new()
    mi.mesh = entry["mesh"]
    var names: Array = entry["names"]
    for i in names.size():
        if names[i] == "paint":
            mi.set_surface_override_material(i, body_mat)
        elif names[i] == "tail":
            mi.set_surface_override_material(i, tail_mat)
    root.add_child(mi)

    var size: Vector3 = data["size"]
    var cabin: Vector3 = data["cabin"]
    var sill: float = data["sill"]
    var belt := sill + size.y * 0.97
    _add_collider(root, size, Vector3(0.0, sill + size.y * 0.5, 0.0))
    _add_collider(root, cabin, Vector3(0.0, belt + cabin.y * 0.5, float(data["cabin_z"])))
    if data.get("cargo", false):
        var cz := float(data["cabin_z"]) + cabin.z * 0.5 + 0.1
        var cl := size.z * 0.5 - 0.1 - cz
        _add_collider(root, Vector3(size.x, 2.1, cl), Vector3(0.0, belt + 1.05, cz + cl * 0.5))

    if wheel_meshes:
        var radius: float = data["wheel_radius"]
        for p: Vector3 in wheel_positions(data):
            var wheel := make_wheel(radius)
            wheel.position = Vector3(p.x, -0.5, p.z)
            root.add_child(wheel)
    return {"body_mat": body_mat, "tail_mat": tail_mat}


static func _add_collider(root: Node3D, size: Vector3, pos: Vector3) -> void:
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = size
    shape.shape = box
    shape.position = pos
    root.add_child(shape)


static func make_wheel(radius: float) -> MeshInstance3D:
    var key := snappedf(radius, 0.01)
    if not _wheel_cache.has(key):
        _wheel_cache[key] = _wheel_mesh(radius)
    var mi := MeshInstance3D.new()
    mi.mesh = _wheel_cache[key]
    return mi


static func _wheel_mesh(r: float) -> ArrayMesh:
    var st := GeoScript.new_st()
    var hw := 0.12 + r * 0.12
    var tire := Color(0.04, 0.04, 0.045)
    var rim := Color(0.72, 0.72, 0.76)
    var dark := Color(0.12, 0.12, 0.14)
    var segs := 16
    GeoScript.tread_x(st, -hw, hw, r, segs, tire)
    for side: float in [-1.0, 1.0]:
        var x := hw * side
        GeoScript.ring_x(st, x, r * 0.72, r, segs, side, tire)
        GeoScript.ring_x(st, x + side * 0.004, r * 0.5, r * 0.72, segs, side, rim)
        GeoScript.disc_x(st, Vector3(x + side * 0.002, 0.0, 0.0), r * 0.5, segs, side, dark)
        for k in 5:
            var a := TAU * float(k) / 5.0
            var d0 := Vector3(0.0, cos(a), sin(a))
            var perp := Vector3(0.0, -sin(a), cos(a)) * (0.06 * r)
            var c := Vector3(x + side * 0.006, 0.0, 0.0)
            GeoScript.quad(st, c - perp, c + perp, c + perp + d0 * (r * 0.5), c - perp + d0 * (r * 0.5), Vector3(side, 0, 0), rim)
    var mesh := ArrayMesh.new()
    st.commit(mesh)
    mesh.surface_set_material(0, _shared_material("wheel"))
    return mesh


static func _box(st: SurfaceTool, base: Vector3, size: Vector3) -> void:
    GeoScript.box(st, base, size, Vector2.ONE, 0.0, Color.WHITE, true, true, true)


static func _build_mesh(data: Dictionary) -> Dictionary:
    var sts := {}
    for n in ["paint", "glass", "trim", "head", "tail", "plate", "cargo"]:
        sts[n] = GeoScript.new_st()
    var paint: SurfaceTool = sts["paint"]
    var glass: SurfaceTool = sts["glass"]
    var trim: SurfaceTool = sts["trim"]
    var head: SurfaceTool = sts["head"]
    var tail: SurfaceTool = sts["tail"]
    var plate: SurfaceTool = sts["plate"]
    var cargo: SurfaceTool = sts["cargo"]

    var size: Vector3 = data["size"]
    var cabin: Vector3 = data["cabin"]
    var cz: float = data["cabin_z"]
    var sill: float = data["sill"]
    var w := size.x
    var h := size.y
    var l := size.z
    var z0 := -l * 0.5
    var z1 := l * 0.5
    var belt := sill + h * 0.97
    var is_box: bool = data.get("box", false)

    # carroceria baixa
    var secs: Array = []
    if is_box:
        secs = [
            {"z": z0, "hw": w * 0.48, "y0": sill + 0.15, "y1": belt},
            {"z": z0 + 0.12, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1 - 0.12, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1, "hw": w * 0.48, "y0": sill + 0.15, "y1": belt},
        ]
    else:
        var hood := maxf(float(data.get("hood", 0.25)), 0.12)
        var trunk := maxf(float(data.get("trunk", 0.15)), 0.05)
        secs = [
            {"z": z0, "hw": w * 0.44, "y0": sill + 0.14, "y1": sill + h * 0.5},
            {"z": z0 + l * 0.03, "hw": w * 0.48, "y0": sill + 0.08, "y1": sill + h * 0.7},
            {"z": z0 + l * 0.1, "hw": w * 0.5, "y0": sill, "y1": sill + h * 0.84},
            {"z": z0 + l * hood, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1 - l * trunk, "hw": w * 0.5, "y0": sill, "y1": belt},
            {"z": z1 - l * 0.03, "hw": w * 0.48, "y0": sill, "y1": sill + h * 0.88},
            {"z": z1, "hw": w * 0.44, "y0": sill + 0.1, "y1": sill + h * 0.66},
        ]
    GeoScript.loft_all(paint, secs)

    # cabine (para-brisa e vidro traseiro inclinados, laterais de vidro, teto pintado)
    var cw := cabin.x
    var ch := cabin.y
    var cl := cabin.z
    var slope_f := minf(cl * 0.3, 0.7)
    var slope_r := minf(cl * 0.25, 0.6)
    if is_box:
        slope_f = minf(cl * 0.12, 0.4)
        slope_r = 0.0
    var c0 := {"z": cz - cl * 0.5, "hw": cw * 0.485, "y0": belt, "y1": belt + 0.04}
    var c1 := {"z": cz - cl * 0.5 + slope_f, "hw": cw * 0.43, "y0": belt, "y1": belt + ch}
    var c2 := {"z": cz + cl * 0.5 - slope_r, "hw": cw * 0.43, "y0": belt, "y1": belt + ch}
    var c3 := {"z": cz + cl * 0.5, "hw": cw * 0.485, "y0": belt, "y1": belt + 0.04}
    GeoScript.loft_segment(c0, c1, glass, null, glass)
    GeoScript.loft_segment(c1, c2, paint, null, glass)
    if slope_r > 0.0:
        GeoScript.loft_segment(c2, c3, glass, null, glass)
    else:
        GeoScript.loft_cap(paint, c2, 1.0)

    # frente: para-choque, grade, faróis, placa
    _box(trim, Vector3(0.0, sill + 0.02, z0 + 0.02), Vector3(w * 0.92, 0.2, 0.14))
    _box(trim, Vector3(0.0, sill + h * 0.3, z0 + 0.03), Vector3(w * 0.45, h * 0.24, 0.06))
    for sx: float in [-1.0, 1.0]:
        _box(head, Vector3(sx * w * 0.34, sill + h * 0.5, z0 + 0.05), Vector3(0.36, 0.12, 0.1))
        _box(tail, Vector3(sx * w * 0.36, sill + h * 0.58, z1 - 0.05), Vector3(0.36, 0.12, 0.1))
    _box(plate, Vector3(0.0, sill + 0.06, z0 - 0.03), Vector3(0.5, 0.12, 0.02))
    _box(trim, Vector3(0.0, sill + 0.02, z1 - 0.02), Vector3(w * 0.92, 0.2, 0.14))
    _box(plate, Vector3(0.0, sill + 0.06, z1 + 0.03), Vector3(0.5, 0.12, 0.02))

    # laterais: frestas das portas e retrovisores
    for sx: float in [-1.0, 1.0]:
        for k in [-0.1, 0.32]:
            _box(trim, Vector3(sx * (w * 0.5 + 0.004), sill + h * 0.08, cz + cl * float(k)), Vector3(0.014, h * 0.86, 0.014))
        _box(paint, Vector3(sx * (cw * 0.5 + 0.1), belt + 0.08, cz - cl * 0.5 + 0.35), Vector3(0.1, 0.1, 0.16))

    # caixas de roda
    var radius: float = data["wheel_radius"]
    for p: Vector3 in wheel_positions(data):
        var side := 1.0 if p.x > 0.0 else -1.0
        GeoScript.disc_x(trim, Vector3(side * (w * 0.5 + 0.004), -0.5, p.z), radius * 1.2, 14, side, Color.WHITE)

    if data.get("spoiler", false):
        _box(paint, Vector3(0.0, belt + 0.3, z1 - 0.35), Vector3(w * 0.85, 0.04, 0.28))
        for sx: float in [-1.0, 1.0]:
            _box(trim, Vector3(sx * w * 0.3, belt + 0.06, z1 - 0.35), Vector3(0.05, 0.24, 0.05))
    if data.get("bed", false):
        var zb := cz + cl * 0.5
        var len := z1 - zb
        for sx: float in [-1.0, 1.0]:
            _box(paint, Vector3(sx * (w * 0.5 - 0.03), belt, zb + len * 0.5), Vector3(0.06, 0.34, len))
        _box(paint, Vector3(0.0, belt, z1 - 0.03), Vector3(w, 0.34, 0.06))
        _box(paint, Vector3(0.0, belt, zb), Vector3(w - 0.1, 0.42, 0.06))
    if data.get("cargo", false):
        var zc := cz + cl * 0.5 + 0.1
        var clen := z1 - 0.1 - zc
        _box(cargo, Vector3(0.0, belt, zc + clen * 0.5), Vector3(w, 2.1, clen))
        _box(trim, Vector3(0.0, belt + 1.05, z1 - 0.1), Vector3(0.04, 2.0, 0.03))

    var mesh := ArrayMesh.new()
    var names: Array = []
    for n: String in sts:
        var st: SurfaceTool = sts[n]
        if not GeoScript.has_data(st):
            continue
        st.commit(mesh)
        var idx := mesh.get_surface_count() - 1
        if n != "paint" and n != "tail":
            mesh.surface_set_material(idx, _shared_material(n))
        names.append(n)
    return {"mesh": mesh, "names": names}
