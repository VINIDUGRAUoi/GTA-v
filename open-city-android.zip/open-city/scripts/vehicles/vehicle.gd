extends VehicleBody3D
## Veículo dirigível (física VehicleBody3D). Controles (mesmas ações do jogador):
## move_forward = acelerar, move_back = freio/ré, move_left/right = direção,
## jump = freio de mão. O jogador entra/sai com a ação "interact".

signal crashed(impact: float)

const BuilderScript := preload("res://scripts/vehicles/vehicle_builder.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

## Se o carro andar para trás ao acelerar nos testes, troque para -1.0.
const ENGINE_SIGN := 1.0
const CRASH_DELTA_V := 5.0
const MAX_HEALTH := 100.0

var type_id := "sedan"
var body_color := Color(0.5, 0.5, 0.5)
var data: Dictionary = {}
var driver = null
var health := MAX_HEALTH
var recyclable := false
var display_name := ""

var _body_mat: StandardMaterial3D
var _tail_mat: StandardMaterial3D
var _last_velocity := Vector3.ZERO
var _braking_lights := false


func setup(id: String, color: Color) -> void:
    type_id = id if DataScript.TYPES.has(id) else "sedan"
    body_color = color


func _ready() -> void:
    data = DataScript.TYPES[type_id]
    display_name = data["name"]
    mass = data["mass"]
    center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
    center_of_mass = Vector3(0.0, -0.45, 0.0)
    angular_damp = 0.5
    can_sleep = false

    var parts: Dictionary = BuilderScript.build(self, data, body_color, false)
    _body_mat = parts["body_mat"]
    _tail_mat = parts["tail_mat"]
    _build_wheels()
    add_to_group("vehicles")
    add_to_group("enterable")
    _last_velocity = linear_velocity


func _build_wheels() -> void:
    var radius: float = data["wheel_radius"]
    for p: Vector3 in BuilderScript.wheel_positions(data):
        var wheel := VehicleWheel3D.new()
        wheel.position = p
        var front := p.z < 0.0
        wheel.use_as_steering = front
        wheel.use_as_traction = bool(data["awd"]) or not front
        wheel.wheel_radius = radius
        wheel.wheel_rest_length = 0.2
        wheel.suspension_travel = 0.35
        wheel.suspension_stiffness = data["suspension"]
        wheel.suspension_max_force = float(data["mass"]) * 10.0
        wheel.damping_compression = 0.88
        wheel.damping_relaxation = 0.83
        wheel.wheel_friction_slip = 7.0
        add_child(wheel)

        wheel.add_child(BuilderScript.make_wheel(radius))


# ------------------------------------------------------------ interface comum
# (usada pelo jogador, pelos pedestres e pelo mapa)

func can_enter() -> bool:
    return driver == null


func get_display_name() -> String:
    return display_name


func get_drivable():
    return self


func set_driver(new_driver) -> void:
    driver = new_driver
    sleeping = false


func clear_driver() -> void:
    driver = null


func get_speed() -> float:
    return linear_velocity.length()


func get_forward_xz() -> Vector2:
    var f := -global_transform.basis.z
    var v := Vector2(f.x, f.z)
    return v.normalized() if v.length() > 0.001 else Vector2(0.0, -1.0)


# ------------------------------------------------------------------- física

func _physics_process(delta: float) -> void:
    var fwd := -global_transform.basis.z
    var speed := linear_velocity.dot(fwd)
    var throttle := 0.0
    var brake_amount := 0.0
    var steer_input := 0.0
    var handbrake := false
    var alive := health > 0.0

    if driver != null and alive:
        var accel := Input.get_action_strength("move_forward")
        var reverse := Input.get_action_strength("move_back")
        steer_input = Input.get_action_strength("move_left") - Input.get_action_strength("move_right")
        handbrake = Input.is_action_pressed("jump")
        if accel > 0.0:
            if speed < -1.0:
                brake_amount = accel
            else:
                throttle = accel
        if reverse > 0.0:
            if speed > 1.0:
                brake_amount = maxf(brake_amount, reverse)
            else:
                throttle = -reverse * 0.6
        if accel == 0.0 and reverse == 0.0:
            brake_amount = 0.05
    else:
        brake_amount = 1.0 # estacionado ou quebrado: fica parado

    var max_speed: float = data["max_speed"]
    var limit := max_speed if throttle >= 0.0 else 12.0
    var ratio := clampf(1.0 - absf(speed) / limit, 0.0, 1.0)
    var power_factor := 0.4 + 0.6 * health / MAX_HEALTH
    engine_force = throttle * float(data["power"]) * ratio * power_factor * ENGINE_SIGN

    var brake_force := brake_amount * 0.03 * mass
    if handbrake:
        brake_force = maxf(brake_force, 0.05 * mass)
    brake = brake_force

    var steer_limit: float = float(data["steer"]) * lerpf(1.0, 0.3, clampf(absf(speed) / 25.0, 0.0, 1.0))
    steering = move_toward(steering, steer_input * steer_limit, 3.0 * delta)

    var lights_on := (brake_amount > 0.1 and driver != null) or handbrake
    if lights_on != _braking_lights:
        _braking_lights = lights_on
        _tail_mat.emission_energy_multiplier = 2.5 if lights_on else 0.4

    var dv := (linear_velocity - _last_velocity).length()
    _last_velocity = linear_velocity
    if dv > CRASH_DELTA_V:
        _on_crash(dv)


func _on_crash(impact: float) -> void:
    health = maxf(health - ((impact - CRASH_DELTA_V) * 6.0 + 5.0), 0.0)
    _body_mat.albedo_color = body_color.lerp(Color(0.1, 0.1, 0.1), 1.0 - health / MAX_HEALTH)
    crashed.emit(impact)
    if driver != null and impact > 8.0 and driver.has_method("take_damage"):
        driver.take_damage((impact - 8.0) * 3.0)
