extends RefCounted
## Definições dos veículos (todos originais). Para criar um novo, adicione uma entrada em
## TYPES e o id em IDS. Veja docs/GUIA_CONTEUDO.md.
## size = carroceria baixa (largura, altura, comprimento); cabin = cabine; cabin_z < 0 = mais à frente.
## sill = altura (y) da parte de baixo da carroceria; power = força por roda motriz;
## max_speed em m/s; steer em radianos. hood/trunk = fração do comprimento do capô/porta-malas.
## box = carroceria reta (van/caminhão); bed = caçamba aberta; cargo = baú; spoiler = aerofólio.

const IDS := ["sport", "sedan", "suv", "pickup", "truck", "van"]

const TYPES := {
    "sport": {
        "name": "Esportivo", "mass": 1100.0, "power": 3500.0, "awd": false, "max_speed": 55.0, "steer": 0.5,
        "size": Vector3(1.85, 0.56, 4.3), "cabin": Vector3(1.5, 0.42, 1.9), "cabin_z": 0.25, "sill": -0.72,
        "hood": 0.3, "trunk": 0.14, "spoiler": true,
        "wheel_radius": 0.34, "suspension": 55.0,
        "colors": [Color(0.8, 0.1, 0.1), Color(0.95, 0.75, 0.1), Color(0.1, 0.3, 0.8)],
    },
    "sedan": {
        "name": "Sedã", "mass": 1300.0, "power": 2500.0, "awd": false, "max_speed": 42.0, "steer": 0.5,
        "size": Vector3(1.8, 0.62, 4.5), "cabin": Vector3(1.55, 0.58, 2.3), "cabin_z": 0.15, "sill": -0.7,
        "hood": 0.26, "trunk": 0.18,
        "wheel_radius": 0.34, "suspension": 40.0,
        "colors": [Color(0.75, 0.75, 0.78), Color(0.15, 0.15, 0.2), Color(0.2, 0.5, 0.3), Color(0.6, 0.2, 0.2)],
    },
    "suv": {
        "name": "SUV", "mass": 1900.0, "power": 3200.0, "awd": true, "max_speed": 39.0, "steer": 0.45,
        "size": Vector3(2.0, 0.82, 4.7), "cabin": Vector3(1.8, 0.62, 2.9), "cabin_z": 0.35, "sill": -0.62,
        "hood": 0.2, "trunk": 0.06,
        "wheel_radius": 0.4, "suspension": 40.0,
        "colors": [Color(0.1, 0.1, 0.12), Color(0.85, 0.85, 0.85), Color(0.3, 0.35, 0.2)],
    },
    "pickup": {
        "name": "Caminhonete", "mass": 2000.0, "power": 3000.0, "awd": true, "max_speed": 39.0, "steer": 0.45,
        "size": Vector3(2.0, 0.8, 5.2), "cabin": Vector3(1.8, 0.62, 1.7), "cabin_z": -0.75, "sill": -0.6,
        "hood": 0.2, "trunk": 0.05, "bed": true,
        "wheel_radius": 0.4, "suspension": 38.0,
        "colors": [Color(0.7, 0.35, 0.1), Color(0.8, 0.8, 0.8), Color(0.15, 0.25, 0.5)],
    },
    "truck": {
        "name": "Caminhão", "mass": 5000.0, "power": 5500.0, "awd": true, "max_speed": 28.0, "steer": 0.4,
        "size": Vector3(2.5, 1.0, 7.0), "cabin": Vector3(2.3, 1.2, 2.0), "cabin_z": -2.4, "sill": -0.46,
        "box": true, "cargo": true,
        "wheel_radius": 0.5, "suspension": 35.0,
        "colors": [Color(0.8, 0.5, 0.1), Color(0.2, 0.4, 0.7), Color(0.85, 0.85, 0.85)],
    },
    "van": {
        "name": "Van de serviço", "mass": 2200.0, "power": 2600.0, "awd": false, "max_speed": 33.0, "steer": 0.45,
        "size": Vector3(2.0, 0.92, 5.0), "cabin": Vector3(1.9, 0.9, 3.7), "cabin_z": 0.35, "sill": -0.64,
        "box": true,
        "wheel_radius": 0.38, "suspension": 38.0,
        "colors": [Color(0.95, 0.95, 0.95), Color(0.9, 0.8, 0.1)],
    },
}
