extends Node3D
## Gera a primeira área explorável (Etapa 5, versão inicial): uma grade 6x6 de
## quarteirões com avenidas, prédios com colisão, praças e objetos de teste.
## Tudo usa PLACEHOLDERS geométricos coloridos (sem texturas nem modelos).
## A geração é determinística (SEED fixa) para facilitar testes.

const BLOCK_SIZE := 40.0
const ROAD_WIDTH := 12.0
const PITCH := BLOCK_SIZE + ROAD_WIDTH
const GRID_MIN := -3
const GRID_MAX := 2
const SEED := 1337
const PARK_CHANCE := 0.12
const FLAT_HEIGHT := 0.04

var building_count := 0
var park_count := 0

var _rng := RandomNumberGenerator.new()
var _materials := {}


func build() -> void:
    _rng.seed = SEED
    building_count = 0
    park_count = 0
    _add_environment()
    _add_ground()
    _add_roads()
    _add_blocks()
    _add_test_props()


func _add_environment() -> void:
    var sky_material := ProceduralSkyMaterial.new()
    var sky := Sky.new()
    sky.sky_material = sky_material
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    var world_env := WorldEnvironment.new()
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
    sun.shadow_enabled = not OS.has_feature("mobile") # sombras pesam em celular
    sun.directional_shadow_max_distance = 120.0
    add_child(sun)


func _add_ground() -> void:
    var extent := float(GRID_MAX - GRID_MIN + 1) * PITCH + 2.0 * PITCH
    _add_box(Vector3(extent, 1.0, extent), Vector3(0.0, -0.5, 0.0), Color(0.32, 0.45, 0.28), true)


func _add_roads() -> void:
    var length := float(GRID_MAX - GRID_MIN + 2) * PITCH
    var road_color := Color(0.16, 0.16, 0.18)
    var line_color := Color(0.9, 0.8, 0.2)
    for k in range(GRID_MIN, GRID_MAX + 2):
        var offset := float(k) * PITCH
        # Avenidas ao longo de Z (posição fixa em X) e ao longo de X.
        _add_box(Vector3(ROAD_WIDTH, FLAT_HEIGHT, length), Vector3(offset, FLAT_HEIGHT * 0.5, 0.0), road_color, false)
        _add_box(Vector3(length, FLAT_HEIGHT, ROAD_WIDTH), Vector3(0.0, FLAT_HEIGHT * 0.5, offset), road_color, false)
        _add_box(Vector3(0.2, 0.01, length), Vector3(offset, FLAT_HEIGHT + 0.005, 0.0), line_color, false)
        _add_box(Vector3(length, 0.01, 0.2), Vector3(0.0, FLAT_HEIGHT + 0.007, offset), line_color, false)


func _add_blocks() -> void:
    for i in range(GRID_MIN, GRID_MAX + 1):
        for j in range(GRID_MIN, GRID_MAX + 1):
            var center := Vector3((float(i) + 0.5) * PITCH, 0.0, (float(j) + 0.5) * PITCH)
            if _rng.randf() < PARK_CHANCE:
                _add_box(Vector3(BLOCK_SIZE, FLAT_HEIGHT, BLOCK_SIZE), center + Vector3(0.0, FLAT_HEIGHT * 0.5, 0.0), Color(0.25, 0.6, 0.25), false)
                park_count += 1
            else:
                _add_box(Vector3(BLOCK_SIZE, FLAT_HEIGHT, BLOCK_SIZE), center + Vector3(0.0, FLAT_HEIGHT * 0.5, 0.0), Color(0.6, 0.6, 0.6), false)
                _add_buildings(center)


func _add_buildings(center: Vector3) -> void:
    # Prédios mais altos perto do centro da cidade.
    var distance := Vector2(center.x, center.z).length()
    var height_factor := lerpf(1.6, 0.5, clampf(distance / 250.0, 0.0, 1.0))
    for qx in [-1.0, 1.0]:
        for qz in [-1.0, 1.0]:
            var width := _rng.randf_range(13.0, 18.0)
            var depth := _rng.randf_range(13.0, 18.0)
            var height := _rng.randf_range(8.0, 28.0) * height_factor
            var color := Color.from_hsv(_rng.randf_range(0.5, 0.62), _rng.randf_range(0.05, 0.2), _rng.randf_range(0.45, 0.8))
            var pos := center + Vector3(qx * 10.0, height * 0.5, qz * 10.0)
            _add_box(Vector3(width, height, depth), pos, color, true)
            building_count += 1


func _add_test_props() -> void:
    # Rampa na avenida à frente do ponto de partida (o jogador começa olhando para -Z).
    var ramp := _add_box(Vector3(6.0, 0.4, 10.0), Vector3(0.0, 1.45, -22.0), Color(0.7, 0.5, 0.2), true)
    ramp.rotation_degrees.x = 15.0
    # Caixas para testar pulo e colisão.
    _add_box(Vector3(1.0, 1.0, 1.0), Vector3(4.0, 0.5, -8.0), Color(0.6, 0.4, 0.2), true)
    _add_box(Vector3(1.0, 1.0, 1.0), Vector3(-4.0, 0.5, -8.0), Color(0.6, 0.4, 0.2), true)
    _add_box(Vector3(2.0, 2.0, 2.0), Vector3(-4.0, 1.0, -12.0), Color(0.5, 0.35, 0.2), true)
    _add_box(Vector3(0.5, 1.2, 6.0), Vector3(3.0, 0.6, 8.0), Color(0.5, 0.5, 0.55), true)


func _material(color: Color) -> StandardMaterial3D:
    var key := color.to_html()
    if not _materials.has(key):
        var mat := StandardMaterial3D.new()
        mat.albedo_color = color
        mat.roughness = 0.9
        _materials[key] = mat
    return _materials[key]


func _add_box(size: Vector3, pos: Vector3, color: Color, collide: bool) -> Node3D:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.material_override = _material(color)
    if not collide:
        mesh.position = pos
        add_child(mesh)
        return mesh

    var body := StaticBody3D.new()
    body.position = pos
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    body.add_child(mesh)
    add_child(body)
    return body
