extends Node3D
## Ponto de entrada. Monta mundo, HUD e jogador (nessa ordem, para que os
## sinais do jogador já encontrem o HUD conectado quando ele emitir o estado inicial).

const WorldBuilder := preload("res://scripts/world/world_builder.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const HudScript := preload("res://scripts/ui/hud.gd")
const TouchScript := preload("res://scripts/ui/touch_controls.gd")

const SPAWN_POSITION := Vector3(0.0, 0.1, 0.0)


func _ready() -> void:
    var world := WorldBuilder.new()
    world.name = "World"
    add_child(world)
    world.build()

    var mobile := OS.has_feature("mobile")
    var hud := HudScript.new()
    hud.name = "Hud"
    hud.touch_mode = mobile
    if mobile:
        hud.scale = Vector2(1.5, 1.5)
    add_child(hud)

    var player := PlayerScript.new()
    player.name = "Player"
    player.spawn_position = SPAWN_POSITION
    player.health_changed.connect(hud.set_health)
    player.stamina_changed.connect(hud.set_stamina)
    add_child(player)
    player.global_position = SPAWN_POSITION

    if mobile:
        var layer := CanvasLayer.new()
        layer.name = "TouchLayer"
        add_child(layer)
        var touch := TouchScript.new()
        layer.add_child(touch)
        touch.look_dragged.connect(player.apply_look)
