class_name Player
extends CharacterBody3D
## Personagem em terceira pessoa (Etapa 3).
## Colisão, visual e câmera são criados em código. O visual é um PLACEHOLDER
## (cápsula + "nariz" indicando a frente); será trocado por um modelo animado.

signal health_changed(current: float, maximum: float)
signal stamina_changed(current: float, maximum: float)
signal interact_requested
signal died

const STAND_HEIGHT := 1.8
const CROUCH_HEIGHT := 1.1
const RADIUS := 0.4
const PITCH_MIN := -1.25
const PITCH_MAX := 0.6
const FALL_LIMIT := -30.0
const STAMINA_DRAIN := 22.0
const STAMINA_REGEN := 18.0
const STAMINA_RECOVER_AT := 25.0

@export var walk_speed := 4.0
@export var run_speed := 8.0
@export var crouch_speed := 2.0
@export var jump_velocity := 5.5
@export var acceleration := 25.0
@export var mouse_sensitivity := 0.0025
@export var stick_sensitivity := 2.5
@export var touch_sensitivity := 0.006
@export var camera_distance := 4.5
@export var max_health := 100.0
@export var max_stamina := 100.0

var spawn_position := Vector3.ZERO
var health := 0.0
var stamina := 0.0
var crouching := false

var _yaw := 0.0
var _pitch := -0.25
var _exhausted := false
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _collider: CollisionShape3D
var _capsule: CapsuleShape3D
var _visual: Node3D
var _pivot: Node3D
var _arm: SpringArm3D
var _camera: Camera3D


func _ready() -> void:
    health = max_health
    stamina = max_stamina
    _build_collision()
    _build_visual()
    _build_camera_rig()
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    health_changed.emit(health, max_health)
    stamina_changed.emit(stamina, max_stamina)


# ---------------------------------------------------------------- construção

func _build_collision() -> void:
    _capsule = CapsuleShape3D.new()
    _capsule.radius = RADIUS
    _capsule.height = STAND_HEIGHT
    _collider = CollisionShape3D.new()
    _collider.shape = _capsule
    _collider.position.y = STAND_HEIGHT * 0.5
    add_child(_collider)


func _build_visual() -> void:
    _visual = Node3D.new()
    add_child(_visual)

    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.9, 0.55, 0.15)
    mat.roughness = 0.8

    var body := MeshInstance3D.new()
    var capsule_mesh := CapsuleMesh.new()
    capsule_mesh.radius = RADIUS
    capsule_mesh.height = STAND_HEIGHT
    body.mesh = capsule_mesh
    body.material_override = mat
    body.position.y = STAND_HEIGHT * 0.5
    _visual.add_child(body)

    var nose := MeshInstance3D.new()
    var nose_mesh := BoxMesh.new()
    nose_mesh.size = Vector3(0.2, 0.2, 0.4)
    nose.mesh = nose_mesh
    nose.material_override = mat
    nose.position = Vector3(0.0, 1.4, -0.4)
    _visual.add_child(nose)


func _build_camera_rig() -> void:
    _pivot = Node3D.new()
    _pivot.position = Vector3(0.0, STAND_HEIGHT - 0.3, 0.0)
    add_child(_pivot)

    _arm = SpringArm3D.new()
    _arm.spring_length = camera_distance
    var probe := SphereShape3D.new()
    probe.radius = 0.25
    _arm.shape = probe
    _arm.add_excluded_object(get_rid())
    _pivot.add_child(_arm)

    _camera = Camera3D.new()
    _camera.fov = 75.0
    _arm.add_child(_camera)
    _camera.make_current()


# ------------------------------------------------------------------- entrada

func _unhandled_input(event: InputEvent) -> void:
    var motion := event as InputEventMouseMotion
    if motion != null:
        if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
            _yaw -= motion.relative.x * mouse_sensitivity
            _pitch = clampf(_pitch - motion.relative.y * mouse_sensitivity, PITCH_MIN, PITCH_MAX)
        return

    var click := event as InputEventMouseButton
    if click != null and click.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        return

    if event.is_action_pressed("pause"):
        if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
            Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
        else:
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event.is_action_pressed("interact"):
        interact_requested.emit()
    elif event.is_action_pressed("debug_damage"):
        take_damage(10.0)


func _process(delta: float) -> void:
    var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
    _yaw -= look.x * stick_sensitivity * delta
    _pitch = clampf(_pitch - look.y * stick_sensitivity * delta, PITCH_MIN, PITCH_MAX)
    _pivot.rotation = Vector3(_pitch, _yaw, 0.0)


## Chamado pelos controles de toque (deslocamento do dedo em pixels).
func apply_look(relative: Vector2) -> void:
    _yaw -= relative.x * touch_sensitivity
    _pitch = clampf(_pitch - relative.y * touch_sensitivity, PITCH_MIN, PITCH_MAX)


# ------------------------------------------------------------------- física

func _physics_process(delta: float) -> void:
    _set_crouching(Input.is_action_pressed("crouch"))

    var move := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var dir := Basis(Vector3.UP, _yaw) * Vector3(move.x, 0.0, move.y)

    var wants_sprint := Input.is_action_pressed("sprint") and move.length() > 0.1 and not crouching
    var sprinting := wants_sprint and not _exhausted and stamina > 0.0
    var speed := walk_speed
    if crouching:
        speed = crouch_speed
    elif sprinting:
        speed = run_speed
    _update_stamina(sprinting, delta)

    var target := dir * speed
    velocity.x = move_toward(velocity.x, target.x, acceleration * delta)
    velocity.z = move_toward(velocity.z, target.z, acceleration * delta)

    if is_on_floor():
        if Input.is_action_just_pressed("jump") and not crouching:
            velocity.y = jump_velocity
    else:
        velocity.y -= _gravity * delta

    move_and_slide()

    if dir.length() > 0.1:
        var target_angle := atan2(-dir.x, -dir.z)
        _visual.rotation.y = lerp_angle(_visual.rotation.y, target_angle, 12.0 * delta)

    if global_position.y < FALL_LIMIT:
        respawn()


func _set_crouching(value: bool) -> void:
    if value == crouching:
        return
    if not value and not _can_stand():
        return
    crouching = value
    var h := CROUCH_HEIGHT if crouching else STAND_HEIGHT
    _capsule.height = h
    _collider.position.y = h * 0.5
    _visual.scale.y = h / STAND_HEIGHT
    _pivot.position.y = h - 0.3


func _can_stand() -> bool:
    var space := get_world_3d().direct_space_state
    var from := global_position + Vector3.UP * CROUCH_HEIGHT
    var to := global_position + Vector3.UP * (STAND_HEIGHT + 0.05)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [get_rid()]
    return space.intersect_ray(query).is_empty()


func _update_stamina(sprinting: bool, delta: float) -> void:
    var previous := stamina
    if sprinting:
        stamina = maxf(stamina - STAMINA_DRAIN * delta, 0.0)
        if stamina <= 0.0:
            _exhausted = true
    else:
        stamina = minf(stamina + STAMINA_REGEN * delta, max_stamina)
        if _exhausted and stamina >= STAMINA_RECOVER_AT:
            _exhausted = false
    if not is_equal_approx(previous, stamina):
        stamina_changed.emit(stamina, max_stamina)


# ----------------------------------------------------------------- vida

func take_damage(amount: float) -> void:
    if amount <= 0.0:
        return
    health = maxf(health - amount, 0.0)
    health_changed.emit(health, max_health)
    if health <= 0.0:
        died.emit()
        respawn()


func heal(amount: float) -> void:
    if amount <= 0.0:
        return
    health = minf(health + amount, max_health)
    health_changed.emit(health, max_health)


func respawn() -> void:
    global_position = spawn_position
    velocity = Vector3.ZERO
    health = max_health
    stamina = max_stamina
    _exhausted = false
    health_changed.emit(health, max_health)
    stamina_changed.emit(stamina, max_stamina)
