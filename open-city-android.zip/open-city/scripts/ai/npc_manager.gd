extends Node
## Cria e recicla pedestres e carros do trânsito ao redor do jogador. Os que ficam
## longe demais são reposicionados perto (sem criar/destruir nós), e as quantidades
## seguem as configurações de gráficos (GameSettings).

const PedScript := preload("res://scripts/ai/pedestrian.gd")
const TrafficScript := preload("res://scripts/ai/traffic_car.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

const DESPAWN_DISTANCE := 170.0
const SPAWN_MIN := 40.0
const SPAWN_MAX := 140.0
const MAX_NEW_PER_TICK := 3
const ABANDONED_DISTANCE := 200.0

var player: Node3D

var _peds: Array = []
var _cars: Array = []
var _timer := 0.0
var _first := true


func _physics_process(delta: float) -> void:
    _timer -= delta
    if _timer > 0.0:
        return
    _timer = 0.5
    if player == null or not is_instance_valid(player):
        return
    _peds = _peds.filter(func(n: Variant) -> bool: return is_instance_valid(n))
    _cars = _cars.filter(func(n: Variant) -> bool: return is_instance_valid(n))

    var budget := 500 if _first else MAX_NEW_PER_TICK
    var rmin := 15.0 if _first else SPAWN_MIN
    _first = false
    budget = _sync_peds(GameSettings.ped_count, budget, rmin)
    _sync_cars(GameSettings.traffic_count, budget, rmin)
    _recycle()
    _cleanup_abandoned()


func _sync_peds(target_count: int, budget: int, rmin: float) -> int:
    while _peds.size() < target_count and budget > 0:
        var nodes := GraphScript.ped_nodes_in_range(player.global_position, rmin, SPAWN_MAX)
        if nodes.is_empty():
            break
        var ped = PedScript.new()
        ped.place(nodes.pick_random())
        add_child(ped)
        _peds.append(ped)
        budget -= 1
    while _peds.size() > target_count:
        var extra = _peds.pop_back()
        extra.queue_free()
    return budget


func _sync_cars(target_count: int, budget: int, rmin: float) -> int:
    while _cars.size() < target_count and budget > 0:
        var car = _make_car(rmin)
        if car == null:
            break
        add_child(car)
        _cars.append(car)
        budget -= 1
    while _cars.size() > target_count:
        var extra = _cars.pop_back()
        extra.queue_free()
    return budget


func _make_car(rmin: float) -> Node:
    var starts := GraphScript.traffic_starts_in_range(player.global_position, rmin, SPAWN_MAX)
    if starts.is_empty():
        return null
    var id: String = DataScript.IDS.pick_random()
    var colors: Array = DataScript.TYPES[id]["colors"]
    var color: Color = colors.pick_random()
    var car = TrafficScript.new()
    car.setup(id, color)
    for attempt in 6:
        var s: Dictionary = starts.pick_random()
        car.start(s["ix"], s["iz"], s["dir"])
        if _is_free_spot(car.position):
            return car
    car.free()
    return null


func _is_free_spot(pos: Vector3) -> bool:
    if Vector2(pos.x - player.global_position.x, pos.z - player.global_position.z).length() < 20.0:
        return false
    for other in _cars:
        if is_instance_valid(other) and other.position.distance_to(pos) < 10.0:
            return false
    return true


func _recycle() -> void:
    var center := player.global_position
    for ped in _peds:
        if Vector2(ped.global_position.x - center.x, ped.global_position.z - center.z).length() > DESPAWN_DISTANCE:
            var nodes := GraphScript.ped_nodes_in_range(center, SPAWN_MIN, SPAWN_MAX)
            if not nodes.is_empty():
                ped.place(nodes.pick_random())
    for car in _cars:
        if Vector2(car.global_position.x - center.x, car.global_position.z - center.z).length() > DESPAWN_DISTANCE:
            var starts := GraphScript.traffic_starts_in_range(center, SPAWN_MIN, SPAWN_MAX)
            if not starts.is_empty():
                var s: Dictionary = starts.pick_random()
                car.start(s["ix"], s["iz"], s["dir"])


## Carros do trânsito que o jogador pegou e largou longe são removidos.
func _cleanup_abandoned() -> void:
    var center := player.global_position
    for v in get_tree().get_nodes_in_group("vehicles"):
        if v.recyclable and v.driver == null:
            if Vector2(v.global_position.x - center.x, v.global_position.z - center.z).length() > ABANDONED_DISTANCE:
                v.queue_free()
