extends RefCounted
## Grafo da cidade em grade: calçadas dos pedestres, vias do trânsito e rota do GPS.
## Mundo de 20x20 quarteirões (aprox. 1,0 km de lado). As constantes de grade vêm daqui
## e são usadas também pelo world_builder.gd.

const BLOCK_SIZE := 40.0
const ROAD_WIDTH := 12.0
const PITCH := 52.0
const BLOCK_MIN := -10
const BLOCK_MAX := 9
const ROAD_MIN := -10
const ROAD_MAX := 10
const RING := 22.5 # distância do centro do quarteirão até a "calçada" dos pedestres

const CORNER_SIGNS := [Vector2i(-1, -1), Vector2i(1, -1), Vector2i(1, 1), Vector2i(-1, 1)]
const DIRS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]


static func city_half_extent() -> float:
    return (ROAD_MAX + 0.5) * PITCH


static func corner_index(sx: int, sz: int) -> int:
    if sx < 0:
        return 0 if sz < 0 else 3
    return 1 if sz < 0 else 2


static func block_in_range(i: int, j: int) -> bool:
    return i >= BLOCK_MIN and i <= BLOCK_MAX and j >= BLOCK_MIN and j <= BLOCK_MAX


static func ped_corner_pos(i: int, j: int, c: int) -> Vector3:
    var s: Vector2i = CORNER_SIGNS[c]
    return Vector3((i + 0.5) * PITCH + s.x * RING, 0.0, (j + 0.5) * PITCH + s.y * RING)


## Vizinhos de um canto de calçada: os dois cantos adjacentes do mesmo quarteirão
## e as travessias da rua até os quarteirões vizinhos.
static func ped_neighbors(i: int, j: int, c: int) -> Array:
    var result: Array = []
    result.append(Vector3i(i, j, (c + 1) % 4))
    result.append(Vector3i(i, j, (c + 3) % 4))
    var s: Vector2i = CORNER_SIGNS[c]
    if block_in_range(i + s.x, j):
        result.append(Vector3i(i + s.x, j, corner_index(-s.x, s.y)))
    if block_in_range(i, j + s.y):
        result.append(Vector3i(i, j + s.y, corner_index(s.x, -s.y)))
    return result


static func ped_nodes_in_range(center: Vector3, rmin: float, rmax: float) -> Array:
    var out: Array = []
    var i0 := clampi(floori((center.x - rmax) / PITCH) - 1, BLOCK_MIN, BLOCK_MAX)
    var i1 := clampi(floori((center.x + rmax) / PITCH) + 1, BLOCK_MIN, BLOCK_MAX)
    var j0 := clampi(floori((center.z - rmax) / PITCH) - 1, BLOCK_MIN, BLOCK_MAX)
    var j1 := clampi(floori((center.z + rmax) / PITCH) + 1, BLOCK_MIN, BLOCK_MAX)
    for i in range(i0, i1 + 1):
        for j in range(j0, j1 + 1):
            for c in 4:
                var p := ped_corner_pos(i, j, c)
                var d := Vector2(p.x - center.x, p.z - center.z).length()
                if d >= rmin and d <= rmax:
                    out.append(Vector3i(i, j, c))
    return out


## Trechos de via (de um cruzamento até o seguinte) cujo ponto médio está no anel [rmin, rmax].
static func traffic_starts_in_range(center: Vector3, rmin: float, rmax: float) -> Array:
    var out: Array = []
    var i0 := clampi(floori((center.x - rmax) / PITCH) - 1, ROAD_MIN, ROAD_MAX)
    var i1 := clampi(floori((center.x + rmax) / PITCH) + 1, ROAD_MIN, ROAD_MAX)
    var j0 := clampi(floori((center.z - rmax) / PITCH) - 1, ROAD_MIN, ROAD_MAX)
    var j1 := clampi(floori((center.z + rmax) / PITCH) + 1, ROAD_MIN, ROAD_MAX)
    for ix in range(i0, i1 + 1):
        for iz in range(j0, j1 + 1):
            for d: Vector2i in DIRS:
                var nx := ix + d.x
                var nz := iz + d.y
                if nx < ROAD_MIN or nx > ROAD_MAX or nz < ROAD_MIN or nz > ROAD_MAX:
                    continue
                var mid := Vector2((ix + d.x * 0.5) * PITCH, (iz + d.y * 0.5) * PITCH)
                var dist := Vector2(mid.x - center.x, mid.y - center.z).length()
                if dist >= rmin and dist <= rmax:
                    out.append({"ix": ix, "iz": iz, "dir": d})
    return out


static func nearest_road_index(v: float) -> int:
    return clampi(roundi(v / PITCH), ROAD_MIN, ROAD_MAX)


static func snap_to_road(p: Vector2) -> Vector2:
    var half := city_half_extent()
    var kx := nearest_road_index(p.x)
    var kz := nearest_road_index(p.y)
    var dx := absf(p.x - kx * PITCH)
    var dz := absf(p.y - kz * PITCH)
    if dx <= dz:
        return Vector2(kx * PITCH, clampf(p.y, -half, half))
    return Vector2(clampf(p.x, -half, half), kz * PITCH)


## Rota simples pelas avenidas (em L pelos cruzamentos). Retorna pontos x,z.
static func route(from: Vector2, to: Vector2) -> PackedVector2Array:
    var a := snap_to_road(from)
    var b := snap_to_road(to)
    var ia := Vector2(nearest_road_index(a.x), nearest_road_index(a.y)) * PITCH
    var ib := Vector2(nearest_road_index(b.x), nearest_road_index(b.y)) * PITCH
    var corner := Vector2(ib.x, ia.y)
    return PackedVector2Array([from, a, ia, corner, ib, b, to])
