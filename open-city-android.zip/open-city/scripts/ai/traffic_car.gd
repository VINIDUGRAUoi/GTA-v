extends AnimatableBody3D
## Carro do trânsito (segue as avenidas na faixa da direita, vira nos cruzamentos e freia
## diante de obstáculos) ou carro ESTACIONADO (parked = true: parado na calçada, quase sem
## custo). O jogador pode "entrar" em qualquer um: get_drivable() troca este carro por um
## veículo dirigível na mesma posição. Pode ser danificado (tiros, explosões).
## Ainda NÃO obedece a semáforos (não existem).

const BuilderScript := preload("res://scripts/vehicles/vehicle_builder.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const ExplosionScript := preload("res://scripts/combat/explosion.gd")

const LANE_OFFSET := 3.0
const REST_HEIGHT := 0.9

var type_id := "sedan"
var body_color := Color(0.5, 0.5, 0.5)
var data: Dictionary = {}
var speed := 0.0
var cruise_speed := 9.0
var parked := false
var health := 100.0

var _dir := Vector2i(1, 0)
var _node := Vector2i.ZERO
var _target := Vector3.ZERO
var _blocked_time := 0.0
var _ignore_until_ms := 0
var _disabled := false
var _body_mat: StandardMaterial3D


func setup(id: String, color: Color) -> void:
    type_id = id if DataScript.TYPES.has(id) else "sedan"
    body_color = color
    data = DataScript.TYPES[type_id]
    cruise_speed = minf(randf_range(7.0, 13.0), float(data["max_speed"]) * 0.5)


func _ready() -> void:
    if data.is_empty():
        setup(type_id, body_color)
    var parts: Dictionary = BuilderScript.build(self, data, body_color, true)
    _body_mat = parts["body_mat"]
    if not parked:
        add_to_group("traffic")
    add_to_group("enterable")


## Posiciona o carro num trecho: sai do cruzamento (ix, iz) na direção dir.
func start(ix: int, iz: int, dir: Vector2i) -> void:
    _dir = dir
    _node = Vector2i(ix + dir.x, iz + dir.y)
    var origin := Vector3(ix * GraphScript.PITCH, REST_HEIGHT, iz * GraphScript.PITCH)
    var along := Vector3(dir.x, 0.0, dir.y) * GraphScript.PITCH * randf_range(0.15, 0.85)
    position = origin + along + _lane(dir)
    rotation.y = atan2(-dir.x, -dir.y)
    speed = 0.0
    _blocked_time = 0.0
    _update_target()


func _lane(dir: Vector2i) -> Vector3:
    return Vector3(-dir.y, 0.0, dir.x) * LANE_OFFSET


func _update_target() -> void:
    _target = Vector3(_node.x * GraphScript.PITCH, REST_HEIGHT, _node.y * GraphScript.PITCH) + _lane(_dir)


func _choose_next() -> void:
    var options: Array = []
    for d: Vector2i in GraphScript.DIRS:
        if d == -_dir:
            continue
        var n := _node + d
        if n.x < GraphScript.ROAD_MIN or n.x > GraphScript.ROAD_MAX or n.y < GraphScript.ROAD_MIN or n.y > GraphScript.ROAD_MAX:
            continue
        options.append(d)
    if options.is_empty():
        options.append(-_dir)
    var next: Vector2i = _dir
    if not (options.has(_dir) and randf() < 0.55):
        next = options.pick_random()
    _dir = next
    _node += next
    _update_target()


func _physics_process(delta: float) -> void:
    if parked:
        return
    if _disabled:
        speed = move_toward(speed, 0.0, 12.0 * delta)
        global_position += -global_transform.basis.z * speed * delta
        return
    var to_target := _target - global_position
    to_target.y = 0.0
    var dist := to_target.length()
    if dist < 2.5:
        _choose_next()
        to_target = _target - global_position
        to_target.y = 0.0
        dist = maxf(to_target.length(), 0.01)

    var desired := to_target / dist
    rotation.y = lerp_angle(rotation.y, atan2(-desired.x, -desired.z), minf(1.0, 4.0 * delta))

    var target_speed := cruise_speed * _obstacle_factor(delta)
    var rate := 6.0 if target_speed > speed else 14.0
    speed = move_toward(speed, target_speed, rate * delta)
    var fwd := -global_transform.basis.z
    global_position += fwd * speed * delta


func _obstacle_factor(delta: float) -> float:
    var fwd := -global_transform.basis.z
    var length := 4.0 + speed * 1.2
    var from := global_position + fwd * (float(data["size"].z) * 0.5 + 0.1) + Vector3(0.0, 0.2, 0.0)
    var query := PhysicsRayQueryParameters3D.create(from, from + fwd * length)
    query.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _blocked_time = 0.0
        return 1.0
    if Time.get_ticks_msec() < _ignore_until_ms:
        return 0.4
    _blocked_time += delta
    if _blocked_time > 5.0: # destrava: segue devagar por 2 s
        _blocked_time = 0.0
        _ignore_until_ms = Time.get_ticks_msec() + 2000
    var d := from.distance_to(hit["position"])
    return clampf((d - 1.5) / maxf(length - 1.5, 0.1), 0.0, 1.0)


## Dano de tiros e explosões. Sem vida o carro para; muito dano faz explodir.
func take_damage(amount: float) -> void:
    if health <= 0.0 or amount <= 0.0:
        return
    health = maxf(health - amount, 0.0)
    if _body_mat != null:
        _body_mat.albedo_color = body_color.lerp(Color(0.1, 0.1, 0.1), 1.0 - health / 100.0)
    if health <= 0.0:
        _disabled = true
        ExplosionScript.create(get_parent(), global_position, 6.0, 100.0, null)


# ------------------------------------------------------------ interface comum

func can_enter() -> bool:
    return health > 0.0


func get_display_name() -> String:
    return str(data["name"])


func get_speed() -> float:
    return speed


func get_forward_xz() -> Vector2:
    var f := -global_transform.basis.z
    return Vector2(f.x, f.z).normalized()


## Troca este carro por um veículo dirigível na mesma posição e velocidade.
func get_drivable():
    var vehicle = FactoryScript.create(type_id, body_color)
    var xform := global_transform
    var vel := -xform.basis.z * speed
    get_parent().add_child(vehicle)
    # o veículo dirigível tem a frente em +Z; este carro tem a frente em -Z
    vehicle.global_transform = Transform3D(xform.basis.rotated(Vector3.UP, PI), xform.origin)
    vehicle.linear_velocity = vel
    vehicle.health = health
    vehicle.recyclable = true
    remove_from_group("enterable")
    queue_free()
    return vehicle
