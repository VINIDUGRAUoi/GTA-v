extends RefCounted
## Pessoa "low-poly" detalhada, montada em código: cabeça com cabelo e olhos, pescoço,
## tronco, ombros, braços articulados, pernas articuladas e sapatos. Os pés ficam
## exatamente no chão (origem no pé). Animação de andar: swing de pernas e braços.

const GeoScript := preload("res://scripts/core/geo.gd")

const SKIN_TONES := [Color(0.95, 0.78, 0.65), Color(0.85, 0.65, 0.5), Color(0.68, 0.48, 0.35), Color(0.5, 0.34, 0.24), Color(0.36, 0.24, 0.17)]
const SHIRTS := [Color(0.8, 0.2, 0.2), Color(0.2, 0.4, 0.8), Color(0.9, 0.9, 0.9), Color(0.2, 0.6, 0.3), Color(0.9, 0.7, 0.2), Color(0.5, 0.2, 0.6), Color(0.15, 0.15, 0.18), Color(0.85, 0.5, 0.6)]
const PANTS := [Color(0.15, 0.2, 0.35), Color(0.2, 0.2, 0.22), Color(0.45, 0.38, 0.28), Color(0.3, 0.3, 0.5), Color(0.55, 0.55, 0.58)]
const HAIRS := [Color(0.08, 0.06, 0.05), Color(0.3, 0.2, 0.12), Color(0.7, 0.55, 0.3), Color(0.5, 0.5, 0.5), Color(0.45, 0.15, 0.1)]

static var _material: StandardMaterial3D


static func _mat() -> StandardMaterial3D:
    if _material == null:
        _material = StandardMaterial3D.new()
        _material.vertex_color_use_as_albedo = true
        _material.roughness = 0.85
        _material.cull_mode = BaseMaterial3D.CULL_DISABLED
    return _material


static func random_outfit() -> Dictionary:
    return {
        "skin": SKIN_TONES.pick_random(),
        "shirt": SHIRTS.pick_random(),
        "pants": PANTS.pick_random(),
        "hair": HAIRS.pick_random(),
        "shoe": Color(0.08, 0.08, 0.09),
        "long_hair": randf() < 0.4,
        "scale": randf_range(0.92, 1.08),
        "backpack": false,
    }


static func _instance(parent: Node3D, st: SurfaceTool, far_cull: float) -> MeshInstance3D:
    var mesh := ArrayMesh.new()
    st.commit(mesh)
    mesh.surface_set_material(0, _mat())
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    if far_cull > 0.0:
        mi.visibility_range_end = far_cull
    parent.add_child(mi)
    return mi


## Cria a pessoa dentro de `parent`. Retorna {"root", "leg_l", "leg_r", "arm_l", "arm_r"}.
static func build(parent: Node3D, outfit: Dictionary, far_cull: float = 0.0) -> Dictionary:
    var skin: Color = outfit["skin"]
    var shirt: Color = outfit["shirt"]
    var pants: Color = outfit["pants"]
    var hair: Color = outfit["hair"]
    var shoe: Color = outfit["shoe"]

    var root := Node3D.new()
    root.scale = Vector3.ONE * float(outfit.get("scale", 1.0))
    parent.add_child(root)

    # tronco (achatado em z) + quadril
    var torso := GeoScript.new_st()
    GeoScript.cylinder(torso, Vector3(0.0, 0.84, 0.0), 0.16, 0.16, 0.14, 10, pants)
    GeoScript.cylinder(torso, Vector3(0.0, 0.96, 0.0), 0.15, 0.19, 0.55, 10, shirt)
    GeoScript.cylinder(torso, Vector3(0.0, 1.5, 0.0), 0.05, 0.05, 0.1, 8, skin)
    GeoScript.sphere(torso, Vector3(-0.2, 1.46, 0.0), 0.07, 4, 8, shirt)
    GeoScript.sphere(torso, Vector3(0.2, 1.46, 0.0), 0.07, 4, 8, shirt)
    var torso_mi := _instance(root, torso, far_cull)
    torso_mi.scale = Vector3(1.0, 1.0, 0.62)

    # cabeça: pele + cabelo (calota) + olhos
    var head := GeoScript.new_st()
    var hc := Vector3(0.0, 1.71, 0.0)
    GeoScript.sphere(head, hc, 0.105, 8, 12, skin, Vector3(0.95, 1.1, 1.0))
    GeoScript.sphere(head, hc + Vector3(0.0, 0.015, 0.012), 0.113, 6, 12, hair, Vector3(0.97, 1.08, 1.0), 1.75)
    if outfit.get("long_hair", false):
        GeoScript.box(head, Vector3(0.0, 1.5, 0.095), Vector3(0.2, 0.28, 0.07), Vector2.ONE, 0.0, hair, true, true, true)
    for sx: float in [-1.0, 1.0]:
        GeoScript.sphere(head, hc + Vector3(sx * 0.04, 0.0, -0.098), 0.014, 3, 6, Color(0.05, 0.05, 0.06))
    _instance(root, head, far_cull)

    # pernas (pivô no quadril, y = 0.92) com sapato
    var legs := GeoScript.new_st()
    GeoScript.cylinder(legs, Vector3(0.0, -0.85, 0.0), 0.06, 0.085, 0.85, 8, pants)
    GeoScript.box(legs, Vector3(0.0, -0.92, -0.04), Vector3(0.11, 0.07, 0.26), Vector2.ONE, 0.0, shoe, true, true, true)
    var leg_mesh := ArrayMesh.new()
    legs.commit(leg_mesh)
    leg_mesh.surface_set_material(0, _mat())
    var leg_l := Node3D.new()
    var leg_r := Node3D.new()
    leg_l.position = Vector3(-0.1, 0.92, 0.0)
    leg_r.position = Vector3(0.1, 0.92, 0.0)
    for leg: Node3D in [leg_l, leg_r]:
        var mi := MeshInstance3D.new()
        mi.mesh = leg_mesh
        if far_cull > 0.0:
            mi.visibility_range_end = far_cull
        leg.add_child(mi)
        root.add_child(leg)

    # braços (pivô no ombro, y = 1.5): manga, antebraço, mão
    var arms := GeoScript.new_st()
    GeoScript.cylinder(arms, Vector3(0.0, -0.3, 0.0), 0.046, 0.058, 0.3, 8, shirt)
    GeoScript.cylinder(arms, Vector3(0.0, -0.58, 0.0), 0.038, 0.045, 0.28, 8, skin)
    GeoScript.sphere(arms, Vector3(0.0, -0.62, 0.0), 0.045, 4, 8, skin)
    var arm_mesh := ArrayMesh.new()
    arms.commit(arm_mesh)
    arm_mesh.surface_set_material(0, _mat())
    var arm_l := Node3D.new()
    var arm_r := Node3D.new()
    arm_l.position = Vector3(-0.25, 1.5, 0.0)
    arm_r.position = Vector3(0.25, 1.5, 0.0)
    for arm: Node3D in [arm_l, arm_r]:
        var mi := MeshInstance3D.new()
        mi.mesh = arm_mesh
        if far_cull > 0.0:
            mi.visibility_range_end = far_cull
        arm.add_child(mi)
        root.add_child(arm)

    if outfit.get("backpack", false):
        var bp := GeoScript.new_st()
        GeoScript.box(bp, Vector3(0.0, 1.0, 0.12), Vector3(0.3, 0.38, 0.14), Vector2.ONE, 0.0, Color(0.15, 0.15, 0.18), true, true, true)
        _instance(root, bp, far_cull)

    return {"root": root, "leg_l": leg_l, "leg_r": leg_r, "arm_l": arm_l, "arm_r": arm_r}


## phase = fase do passo (rad), amount = 0 (parado) a 1 (andando/correndo).
static func animate(rig: Dictionary, phase: float, amount: float) -> void:
    var s := sin(phase) * 0.75 * amount
    var leg_l: Node3D = rig["leg_l"]
    var leg_r: Node3D = rig["leg_r"]
    var arm_l: Node3D = rig["arm_l"]
    var arm_r: Node3D = rig["arm_r"]
    leg_l.rotation.x = s
    leg_r.rotation.x = -s
    arm_l.rotation.x = -s * 0.8
    arm_r.rotation.x = s * 0.8
