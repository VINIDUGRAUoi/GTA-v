extends CharacterBody3D
## Pedestre (visual placeholder). Anda pelas "calçadas" do grafo da cidade, para às vezes,
## foge de veículos rápidos vindo na sua direção e cai se for atingido.
## Estados: WALK, IDLE, FLEE, HIT.

const GraphScript := preload("res://scripts/ai/city_graph.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")

enum State { WALK, IDLE, FLEE, HIT }

var state := State.WALK
var walk_speed := 1.5
var run_speed := 5.5
var node := Vector3i.ZERO
var target := Vector3.ZERO

var _prev := Vector3i.ZERO
var _visual: Node3D
var _rig: Dictionary = {}
var _phase := 0.0
var _t := 0.0
var _scan := 0.0
var _timer := 0.0
var _flee_dir := Vector3.ZERO
var _stuck := 0.0
var _last_pos := Vector3.ZERO
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")


func _ready() -> void:
    collision_layer = 2 # pedestres não colidem entre si nem empurram veículos
    collision_mask = 1
    walk_speed = randf_range(1.2, 1.9)
    _build()
    add_to_group("pedestrians")
    _scan = randf() * 0.25
    _t = randf() * 10.0
    _last_pos = global_position


## Coloca o pedestre no canto de calçada n e escolhe o próximo destino.
func place(n: Vector3i) -> void:
    node = n
    _prev = n
    position = GraphScript.ped_corner_pos(n.x, n.y, n.z) + Vector3(0.0, 0.1, 0.0)
    velocity = Vector3.ZERO
    state = State.WALK
    if _visual != null:
        _visual.rotation.x = 0.0
    _pick_next()


func _build() -> void:
    var shape := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.3
    cap.height = 1.7
    shape.shape = cap
    shape.position.y = 0.85
    add_child(shape)
    _rig = HumanoidScript.build(self, HumanoidScript.random_outfit(), 100.0)
    _visual = _rig["root"]


func _pick_next() -> void:
    var options := GraphScript.ped_neighbors(node.x, node.y, node.z)
    if options.is_empty():
        return
    var filtered := options.filter(func(n: Vector3i) -> bool: return n != _prev)
    if not filtered.is_empty():
        options = filtered
    var next: Vector3i = options.pick_random()
    _prev = node
    node = next
    target = GraphScript.ped_corner_pos(node.x, node.y, node.z)


func _physics_process(delta: float) -> void:
    _t += delta
    _scan -= delta
    if _scan <= 0.0:
        _scan = 0.25
        _scan_threats()

    var moving := false
    match state:
        State.WALK:
            moving = _walk(delta)
        State.IDLE:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                state = State.WALK
        State.FLEE:
            _move(_flee_dir, run_speed, delta)
            moving = true
            _timer -= delta
            if _timer <= 0.0:
                state = State.WALK
        State.HIT:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                _visual.rotation.x = 0.0
                state = State.WALK

    var hspeed := Vector2(velocity.x, velocity.z).length()
    _phase += hspeed * delta * 3.2
    HumanoidScript.animate(_rig, _phase, clampf(hspeed / 2.0, 0.0, 1.0) if moving else 0.0)

    if not is_on_floor():
        velocity.y -= _gravity * delta
    else:
        velocity.y = -0.1
    move_and_slide()

    if state == State.WALK:
        _stuck += delta
        if _stuck > 2.0:
            if (global_position - _last_pos).length() < 0.4:
                _pick_next()
            _last_pos = global_position
            _stuck = 0.0
    if global_position.y < -20.0:
        place(node)


func _walk(delta: float) -> bool:
    var to := target - global_position
    to.y = 0.0
    if to.length() < 0.7:
        if randf() < 0.2:
            state = State.IDLE
            _timer = randf_range(1.5, 4.0)
        else:
            _pick_next()
        return false
    _move(to.normalized(), walk_speed, delta)
    return true


func _move(dir: Vector3, speed: float, delta: float) -> void:
    velocity.x = move_toward(velocity.x, dir.x * speed, 12.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, 12.0 * delta)
    rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 8.0 * delta))


func _stop(delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0.0, 12.0 * delta)
    velocity.z = move_toward(velocity.z, 0.0, 12.0 * delta)


func _scan_threats() -> void:
    if state == State.HIT:
        return
    var pos := global_position
    for group in ["vehicles", "traffic"]:
        for v in get_tree().get_nodes_in_group(group):
            if not v.has_method("get_speed"):
                continue
            var spd: float = v.get_speed()
            if spd < 3.0:
                continue
            var off: Vector3 = pos - v.global_position
            off.y = 0.0
            var dist := off.length()
            if dist > 14.0:
                continue
            if spd > 6.0 and dist < 2.0:
                state = State.HIT
                _timer = 4.0
                _visual.rotation.x = deg_to_rad(-90.0)
                return
            var fwd: Vector2 = v.get_forward_xz()
            var away := Vector2(off.x, off.z).normalized()
            if dist < 12.0 and away.dot(fwd) > 0.5 and state != State.FLEE:
                var side := Vector2(-fwd.y, fwd.x)
                if away.dot(side) < 0.0:
                    side = -side
                _flee_dir = Vector3(side.x, 0.0, side.y)
                state = State.FLEE
                _timer = 2.5
                return
