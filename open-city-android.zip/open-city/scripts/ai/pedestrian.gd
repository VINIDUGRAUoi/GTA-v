extends CharacterBody3D
## Pedestre com esqueleto e animação. Anda pelas "calçadas" do grafo da cidade, para às vezes,
## foge de veículos rápidos e de tiros/explosões, pode levar soco/tiro (vida), reagir
## (fugir ou revidar), cair e morrer. Responde com balão de fala quando o jogador usa "interact".
## Estados: WALK, IDLE, FLEE, HIT, ATTACK, DEAD.

const GraphScript := preload("res://scripts/ai/city_graph.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")

enum State { WALK, IDLE, FLEE, HIT, ATTACK, DEAD }

const PHRASES := [
    "Bom dia!", "Cuidado com o trânsito por aqui.", "Você viu aquele carro esportivo?", "Nossa, que calor hoje...",
    "Estou atrasado para o trabalho!", "Essa cidade não para nunca.", "Se quiser um mapa, aperte M.",
    "Os motoristas daqui são loucos.", "Boa sorte na estrada!", "Tem uma praça bonita pertinho daqui.",
    "Não corra na calçada, amigo!", "Hoje está um dia perfeito.",
]

var state := State.WALK
var role := "walker"
var health := 100.0
var walk_speed := 1.5
var run_speed := 5.5
var node := Vector3i.ZERO
var target := Vector3.ZERO

var _prev := Vector3i.ZERO
var _visual: Node3D
var _rig: Dictionary = {}
var _phase := 0.0
var _scan := 0.0
var _timer := 0.0
var _flee_dir := Vector3.ZERO
var _stuck := 0.0
var _last_pos := Vector3.ZERO
var _bubble: Label3D
var _bubble_timer := 0.0
var _after_hit := State.FLEE
var _threat_pos := Vector3.ZERO
var _attacker: Node3D
var _attack_cd := 0.0
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")


func _ready() -> void:
    collision_layer = 2 # pedestres não colidem entre si nem empurram veículos
    collision_mask = 1
    var roll := randf()
    if roll < 0.2:
        role = "jogger"
    elif roll < 0.35:
        role = "idler"
    walk_speed = randf_range(2.8, 3.6) if role == "jogger" else randf_range(1.2, 1.9)
    _build()
    add_to_group("pedestrians")
    _scan = randf() * 0.25
    _last_pos = global_position
    if role == "idler":
        state = State.IDLE
        _timer = randf_range(2.0, 8.0)


## Coloca o pedestre no canto de calçada n e escolhe o próximo destino.
func place(n: Vector3i) -> void:
    node = n
    _prev = n
    position = GraphScript.ped_corner_pos(n.x, n.y, n.z) + Vector3(0.0, 0.1, 0.0)
    velocity = Vector3.ZERO
    state = State.WALK
    if _visual != null:
        _visual.rotation.x = 0.0
    _pick_next()


func _build() -> void:
    var shape := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.3
    cap.height = 1.7
    shape.shape = cap
    shape.position.y = 0.85
    add_child(shape)
    var rig: Variant = HumanoidScript.build(self, HumanoidScript.random_outfit(), 110.0)
    if rig is Dictionary and (rig as Dictionary).has("skeleton"):
        _rig = rig
        _visual = _rig["root"]
    else:
        _visual = Node3D.new()
        add_child(_visual)
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color.from_hsv(randf(), 0.5, 0.8)
        var body := MeshInstance3D.new()
        var capsule := CapsuleMesh.new()
        capsule.radius = 0.3
        capsule.height = 1.7
        body.mesh = capsule
        body.material_override = mat
        body.position.y = 0.85
        _visual.add_child(body)


func _pick_next() -> void:
    var options := GraphScript.ped_neighbors(node.x, node.y, node.z)
    if options.is_empty():
        return
    var filtered := options.filter(func(n: Vector3i) -> bool: return n != _prev)
    if not filtered.is_empty():
        options = filtered
    var next: Vector3i = options.pick_random()
    _prev = node
    node = next
    target = GraphScript.ped_corner_pos(node.x, node.y, node.z)


# ------------------------------------------------------------------ interações

## Conversa: para, vira para o jogador e mostra um balão de fala.
func talk(player: Node3D) -> void:
    if state == State.HIT or state == State.DEAD:
        return
    state = State.IDLE
    _timer = 4.0
    var off := player.global_position - global_position
    rotation.y = atan2(-off.x, -off.z)
    if _bubble == null:
        _bubble = Label3D.new()
        _bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        _bubble.no_depth_test = true
        _bubble.pixel_size = 0.006
        _bubble.font_size = 40
        _bubble.outline_size = 12
        _bubble.position = Vector3(0.0, 2.25, 0.0)
        _bubble.width = 520.0
        _bubble.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        add_child(_bubble)
    _bubble.text = PHRASES.pick_random()
    _bubble.visible = true
    _bubble_timer = 3.5


## Alerta: barulho (tiro, explosão, briga) perto. Foge para longe da origem.
func alarm(from_pos: Vector3) -> void:
    if state == State.DEAD or state == State.HIT or state == State.ATTACK:
        return
    _threat_pos = from_pos
    var away := global_position - from_pos
    away.y = 0.0
    _flee_dir = away.normalized() if away.length() > 0.1 else Vector3.RIGHT
    state = State.FLEE
    _timer = randf_range(3.0, 5.0)


## Dano de soco, taco, tiro, explosão ou atropelamento.
func apply_damage(amount: float, from_pos: Vector3, kind: String, attacker: Node3D = null) -> void:
    if state == State.DEAD:
        return
    health -= amount
    var away := global_position - from_pos
    away.y = 0.0
    if away.length() > 0.01:
        away = away.normalized()
        velocity += away * (4.5 if kind == "punch" or kind == "bat" else 2.5)
    if health <= 0.0:
        _die()
        return
    _threat_pos = from_pos
    _flee_dir = away if away.length() > 0.1 else Vector3.RIGHT
    _attacker = attacker
    # soco/taco: cambaleia; depois foge ou (uma parte) revida
    var fight_back := (kind == "punch" or kind == "bat") and randf() < 0.3 and attacker != null
    _after_hit = State.ATTACK if fight_back else State.FLEE
    state = State.HIT
    _timer = 0.9 if kind == "punch" or kind == "bat" else 0.5
    _visual.rotation.x = deg_to_rad(-25.0)


func _die() -> void:
    state = State.DEAD
    health = 0.0
    collision_layer = 0
    _timer = 12.0
    _visual.rotation.x = deg_to_rad(-90.0)
    velocity.x = 0.0
    velocity.z = 0.0


# ------------------------------------------------------------------ comportamento

func _physics_process(delta: float) -> void:
    _scan -= delta
    if _scan <= 0.0 and state != State.DEAD:
        _scan = 0.25
        _scan_threats()
    if _bubble != null and _bubble.visible:
        _bubble_timer -= delta
        if _bubble_timer <= 0.0:
            _bubble.visible = false
    _attack_cd = maxf(_attack_cd - delta, 0.0)

    var moving := false
    match state:
        State.WALK:
            moving = _walk(delta)
        State.IDLE:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                if role == "idler" and randf() < 0.6:
                    _timer = randf_range(3.0, 9.0)
                else:
                    state = State.WALK
        State.FLEE:
            _move(_flee_dir, run_speed, delta)
            moving = true
            _timer -= delta
            if _timer <= 0.0:
                state = State.WALK
        State.HIT:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                _visual.rotation.x = 0.0
                state = _after_hit
                _timer = 5.0
        State.ATTACK:
            moving = _attack(delta)
        State.DEAD:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                queue_free()
                return

    var hspeed := Vector2(velocity.x, velocity.z).length()
    _phase += hspeed * delta * 3.2
    var amount := clampf(hspeed / 2.0, 0.0, 1.4) if moving else 0.0
    if _rig.has("skeleton"):
        HumanoidScript.animate(_rig, _phase, amount)
    if _rig.has("skeleton") and state == State.ATTACK and _attack_cd > 0.6:
        var skeleton: Skeleton3D = _rig["skeleton"]
        skeleton.set_bone_pose_rotation(HumanoidScript.UARM_R, Quaternion(Vector3.RIGHT, 1.5))

    if not is_on_floor():
        velocity.y -= _gravity * delta
    else:
        velocity.y = -0.1
    move_and_slide()

    if state == State.WALK:
        _stuck += delta
        if _stuck > 2.0:
            if (global_position - _last_pos).length() < 0.4:
                _pick_next()
            _last_pos = global_position
            _stuck = 0.0
    if global_position.y < -20.0:
        place(node)


func _walk(delta: float) -> bool:
    var to := target - global_position
    to.y = 0.0
    if to.length() < 0.7:
        if randf() < 0.2:
            state = State.IDLE
            _timer = randf_range(1.5, 4.0)
        else:
            _pick_next()
        return false
    _move(to.normalized(), walk_speed, delta)
    return true


## Revida: corre até o jogador e dá socos (dano pequeno).
func _attack(delta: float) -> bool:
    _timer -= delta
    if _attacker == null or not is_instance_valid(_attacker) or _timer <= 0.0:
        state = State.WALK
        return false
    var to := _attacker.global_position - global_position
    to.y = 0.0
    if to.length() > 1.3:
        _move(to.normalized(), 4.5, delta)
        return true
    _stop(delta)
    rotation.y = atan2(-to.x, -to.z)
    if _attack_cd <= 0.0:
        _attack_cd = 1.0
        if _attacker.has_method("take_damage"):
            _attacker.take_damage(5.0)
    return false


func _move(dir: Vector3, speed: float, delta: float) -> void:
    velocity.x = move_toward(velocity.x, dir.x * speed, 12.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, 12.0 * delta)
    rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 8.0 * delta))


func _stop(delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0.0, 12.0 * delta)
    velocity.z = move_toward(velocity.z, 0.0, 12.0 * delta)


func _scan_threats() -> void:
    if state == State.HIT:
        return
    var pos := global_position
    for group in ["vehicles", "traffic"]:
        for v in get_tree().get_nodes_in_group(group):
            if not v.has_method("get_speed"):
                continue
            var spd: float = v.get_speed()
            if spd < 3.0:
                continue
            var off: Vector3 = pos - v.global_position
            off.y = 0.0
            var dist := off.length()
            if dist > 14.0:
                continue
            if spd > 6.0 and dist < 2.0:
                apply_damage(spd * 4.0, v.global_position, "vehicle")
                return
            var fwd: Vector2 = v.get_forward_xz()
            var away := Vector2(off.x, off.z).normalized()
            if dist < 12.0 and away.dot(fwd) > 0.5 and state != State.FLEE:
                var side := Vector2(-fwd.y, fwd.x)
                if away.dot(side) < 0.0:
                    side = -side
                _flee_dir = Vector3(side.x, 0.0, side.y)
                state = State.FLEE
                _timer = 2.5
                return
