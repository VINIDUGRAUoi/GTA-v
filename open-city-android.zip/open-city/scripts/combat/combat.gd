extends Node
## Sistema de combate do jogador: soco, taco, pistola, submetralhadora, fuzil, espingarda,
## sniper, bazuca e granadas. Munição e recarga, tiro por raio a partir do centro da câmera
## (com dispersão), tiro na cabeça com mais dano, rastro e clarão, som sintetizado, alarme
## para os NPCs, arma na mão do personagem e pose de mira/golpe.

const ExplosionScript := preload("res://scripts/combat/explosion.gd")
const GrenadeScript := preload("res://scripts/combat/grenade.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")
const SfxScript := preload("res://scripts/core/sfx.gd")

signal weapon_changed(text: String, ranged: bool)

const WEAPONS := [
    {"id": "fists", "name": "Soco", "melee": true, "damage": 14.0, "range": 1.9, "cooldown": 0.45, "dur": 0.3},
    {"id": "bat", "name": "Taco", "melee": true, "damage": 32.0, "range": 2.3, "cooldown": 0.7, "dur": 0.5},
    {"id": "pistol", "name": "Pistola", "mag": 12, "reserve": 120, "damage": 25.0, "cooldown": 0.28, "spread": 0.6, "range": 90.0, "reload": 1.3, "pellets": 1, "auto": false},
    {"id": "smg", "name": "Submetralhadora", "mag": 30, "reserve": 300, "damage": 13.0, "cooldown": 0.085, "spread": 2.0, "range": 70.0, "reload": 1.8, "pellets": 1, "auto": true, "two_hands": true},
    {"id": "rifle", "name": "Fuzil de assalto", "mag": 30, "reserve": 240, "damage": 21.0, "cooldown": 0.11, "spread": 1.2, "range": 120.0, "reload": 2.0, "pellets": 1, "auto": true, "two_hands": true},
    {"id": "shotgun", "name": "Espingarda", "mag": 6, "reserve": 60, "damage": 11.0, "cooldown": 0.85, "spread": 5.0, "range": 35.0, "reload": 2.2, "pellets": 8, "auto": false, "two_hands": true},
    {"id": "sniper", "name": "Sniper", "mag": 5, "reserve": 40, "damage": 95.0, "cooldown": 1.2, "spread": 0.1, "range": 300.0, "reload": 2.5, "pellets": 1, "auto": false, "two_hands": true},
    {"id": "rocket", "name": "Bazuca", "mag": 1, "reserve": 8, "damage": 200.0, "cooldown": 1.5, "reload": 2.5, "projectile": true, "two_hands": true},
    {"id": "grenade", "name": "Granada", "throwable": true, "cooldown": 0.8},
]

# Partes da arma na mão: [tamanho, posição, cor]. O eixo -Y do osso do antebraço aponta para a frente.
const HELD := {
    "pistol": [[Vector3(0.04, 0.2, 0.05), Vector3(0.0, -0.36, -0.01), 0], [Vector3(0.035, 0.05, 0.09), Vector3(0.0, -0.29, 0.06), 0]],
    "smg": [[Vector3(0.05, 0.28, 0.07), Vector3(0.0, -0.42, 0.0), 0], [Vector3(0.03, 0.05, 0.14), Vector3(0.0, -0.38, 0.1), 0], [Vector3(0.04, 0.12, 0.05), Vector3(0.0, -0.22, 0.0), 0]],
    "rifle": [[Vector3(0.05, 0.5, 0.07), Vector3(0.0, -0.5, 0.0), 0], [Vector3(0.025, 0.2, 0.025), Vector3(0.0, -0.85, -0.01), 0], [Vector3(0.035, 0.06, 0.14), Vector3(0.0, -0.45, 0.1), 0], [Vector3(0.045, 0.18, 0.06), Vector3(0.0, -0.2, 0.01), 0]],
    "shotgun": [[Vector3(0.05, 0.6, 0.06), Vector3(0.0, -0.55, 0.0), 0], [Vector3(0.06, 0.14, 0.06), Vector3(0.0, -0.55, 0.045), 1]],
    "sniper": [[Vector3(0.05, 0.7, 0.06), Vector3(0.0, -0.6, 0.0), 0], [Vector3(0.035, 0.18, 0.04), Vector3(0.0, -0.5, -0.06), 0]],
    "rocket": [[Vector3(0.11, 0.8, 0.11), Vector3(0.0, -0.55, 0.0), 2]],
    "bat": [[Vector3(0.05, 0.7, 0.05), Vector3(0.0, -0.55, 0.0), 1]],
    "grenade": [[Vector3(0.07, 0.1, 0.07), Vector3(0.0, -0.33, 0.0), 2]],
}
const HELD_COLORS := [Color(0.12, 0.12, 0.14), Color(0.45, 0.3, 0.15), Color(0.25, 0.3, 0.15)]

var player: Node3D
var current := 0
var grenades := 10

var _ammo := {}
var _cooldown := 0.0
var _reload_left := 0.0
var _attack_t := 0.0
var _attack_dur := 0.3
var _recent_fire := 0.0
var _attachment: BoneAttachment3D
var _held: Node3D
var _skeleton: Skeleton3D
var _held_visible := true
var ready_ok := false


## Chamado pelo jogador depois de montar o esqueleto.
func setup() -> void:
    for w: Dictionary in WEAPONS:
        if w.has("mag"):
            _ammo[w["id"]] = {"mag": int(w["mag"]), "reserve": int(w["reserve"])}
    var rig: Dictionary = player.get_rig()
    _skeleton = rig["skeleton"]
    _attachment = BoneAttachment3D.new()
    _attachment.bone_name = "farm_r"
    _skeleton.add_child(_attachment)
    select(0)
    ready_ok = true


func current_weapon() -> Dictionary:
    return WEAPONS[current]


func is_ranged() -> bool:
    var w: Dictionary = WEAPONS[current]
    return not w.get("melee", false)


## Verdadeiro logo depois de atirar: o personagem vira para onde a câmera mira.
func is_aiming() -> bool:
    return _recent_fire > 0.0 or _attack_t > 0.0


func select(index: int) -> void:
    current = clampi(index, 0, WEAPONS.size() - 1)
    _reload_left = 0.0
    _build_held()
    _emit_info()


func cycle(direction: int) -> void:
    select((current + direction + WEAPONS.size()) % WEAPONS.size())


func label_for(index: int) -> String:
    var w: Dictionary = WEAPONS[index]
    if w.has("mag"):
        var a: Dictionary = _ammo[w["id"]]
        return "%s  %d/%d" % [w["name"], a["mag"], a["reserve"]]
    if w.get("throwable", false):
        return "%s  x%d" % [w["name"], grenades]
    return str(w["name"])


func set_held_visible(value: bool) -> void:
    _held_visible = value
    if _held != null:
        _held.visible = value


func _emit_info() -> void:
    var text := label_for(current)
    if not WEAPONS[current].get("throwable", false):
        text += "   |   Granadas: %d" % grenades
    weapon_changed.emit(text, is_ranged())


func _build_held() -> void:
    if _held != null:
        _held.queue_free()
        _held = null
    var id: String = WEAPONS[current]["id"]
    if not HELD.has(id):
        return
    _held = Node3D.new()
    _held.visible = _held_visible
    _attachment.add_child(_held)
    for part: Array in HELD[id]:
        var mesh := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = part[0]
        mesh.mesh = box
        var mat := StandardMaterial3D.new()
        mat.albedo_color = HELD_COLORS[int(part[2])]
        mat.roughness = 0.6
        mesh.material_override = mat
        mesh.position = part[1]
        _held.add_child(mesh)


# ------------------------------------------------------------------ entrada / tempo

func _physics_process(delta: float) -> void:
    if not ready_ok or player == null or player.is_driving():
        return
    _cooldown = maxf(_cooldown - delta, 0.0)
    _recent_fire = maxf(_recent_fire - delta, 0.0)
    _attack_t = maxf(_attack_t - delta, 0.0)
    if _reload_left > 0.0:
        _reload_left -= delta
        if _reload_left <= 0.0:
            _finish_reload()

    for n in 9:
        if Input.is_action_just_pressed("weapon_%d" % (n + 1)):
            select(n)
    if Input.is_action_just_pressed("reload"):
        reload()
    if Input.is_action_just_pressed("grenade"):
        throw_grenade()

    var w: Dictionary = WEAPONS[current]
    var wants := Input.is_action_pressed("fire") if w.get("auto", false) else Input.is_action_just_pressed("fire")
    if wants and _cooldown <= 0.0 and _reload_left <= 0.0:
        _use(w)


func _use(w: Dictionary) -> void:
    if w.get("melee", false):
        _melee(w)
    elif w.get("throwable", false):
        throw_grenade()
    elif w.get("projectile", false):
        _launch_rocket(w)
    else:
        _shoot(w)


# ------------------------------------------------------------------ pose do personagem

## Chamado pelo jogador depois da animação de andar: sobe o braço para mirar ou golpear.
func apply_pose(rig: Dictionary) -> void:
    var sk: Skeleton3D = rig["skeleton"]
    var w: Dictionary = WEAPONS[current]
    if _attack_t > 0.0:
        var swing := sin((1.0 - _attack_t / _attack_dur) * PI)
        if w["id"] == "bat":
            sk.set_bone_pose_rotation(HumanoidScript.UARM_R, Quaternion(Vector3.RIGHT, -0.4 + swing * 2.3))
            sk.set_bone_pose_rotation(HumanoidScript.FARM_R, Quaternion(Vector3.RIGHT, 0.3 * swing))
        else:
            sk.set_bone_pose_rotation(HumanoidScript.UARM_R, Quaternion(Vector3.RIGHT, swing * 1.55))
            sk.set_bone_pose_rotation(HumanoidScript.FARM_R, Quaternion(Vector3.RIGHT, 0.05))
            sk.set_bone_pose_rotation(HumanoidScript.UARM_L, Quaternion(Vector3.RIGHT, -swing * 0.5))
        return
    if w.get("melee", false):
        if w["id"] == "bat":
            sk.set_bone_pose_rotation(HumanoidScript.UARM_R, Quaternion(Vector3.RIGHT, 0.5))
        return
    sk.set_bone_pose_rotation(HumanoidScript.UARM_R, Quaternion(Vector3.RIGHT, 1.45))
    sk.set_bone_pose_rotation(HumanoidScript.FARM_R, Quaternion(Vector3.RIGHT, 0.05))
    if w.get("two_hands", false):
        sk.set_bone_pose_rotation(HumanoidScript.UARM_L, Quaternion(Vector3.RIGHT, 1.25))
        sk.set_bone_pose_rotation(HumanoidScript.FARM_L, Quaternion(Vector3.RIGHT, 0.2))


# ------------------------------------------------------------------ ataques

func reload() -> void:
    var w: Dictionary = WEAPONS[current]
    if not w.has("mag") or _reload_left > 0.0:
        return
    var a: Dictionary = _ammo[w["id"]]
    if int(a["mag"]) >= int(w["mag"]) or int(a["reserve"]) <= 0:
        return
    _reload_left = float(w["reload"])


func _finish_reload() -> void:
    var w: Dictionary = WEAPONS[current]
    var a: Dictionary = _ammo[w["id"]]
    var take := mini(int(w["mag"]) - int(a["mag"]), int(a["reserve"]))
    a["mag"] = int(a["mag"]) + take
    a["reserve"] = int(a["reserve"]) - take
    _emit_info()


func _forward_flat() -> Vector3:
    var yaw: float = player.get_yaw()
    return Vector3(-sin(yaw), 0.0, -cos(yaw))


func _alarm(radius: float) -> void:
    var pos: Vector3 = player.global_position
    for ped in get_tree().get_nodes_in_group("pedestrians"):
        if ped.global_position.distance_to(pos) < radius and ped.has_method("alarm"):
            ped.alarm(pos)


func _melee(w: Dictionary) -> void:
    _cooldown = float(w["cooldown"])
    _attack_dur = float(w["dur"])
    _attack_t = _attack_dur
    var origin: Vector3 = player.global_position
    var forward := _forward_flat()
    var best: Node3D = null
    var best_d := float(w["range"])
    for ped in get_tree().get_nodes_in_group("pedestrians"):
        var off: Vector3 = ped.global_position - origin
        off.y = 0.0
        var d := off.length()
        if d < best_d and (d < 0.6 or off.normalized().dot(forward) > 0.2):
            best_d = d
            best = ped
    SfxScript.play_noise(player, 0.08, -14.0, 90.0)
    if best != null and best.has_method("apply_damage"):
        best.apply_damage(float(w["damage"]), origin, "punch" if w["id"] == "fists" else "bat", player)
    _alarm(10.0)


func _muzzle() -> Vector3:
    return _attachment.global_transform * Vector3(0.0, -0.5, 0.0)


func _shoot(w: Dictionary) -> void:
    var a: Dictionary = _ammo[w["id"]]
    if int(a["mag"]) <= 0:
        if int(a["reserve"]) > 0:
            reload()
        return
    a["mag"] = int(a["mag"]) - 1
    _cooldown = float(w["cooldown"])
    _recent_fire = 1.5
    for n in int(w["pellets"]):
        _trace(w)
    var loud := w["id"] == "sniper" or w["id"] == "shotgun"
    SfxScript.play_noise(player, 0.25 if loud else 0.13, -4.0 if loud else -8.0, 110.0 if loud else 150.0)
    _alarm(30.0)
    _emit_info()


func _trace(w: Dictionary) -> void:
    var cam: Camera3D = player.get_camera()
    var chest: Vector3 = player.global_position + Vector3(0.0, 1.4, 0.0)
    var basis := cam.global_transform.basis
    var spread := tan(deg_to_rad(float(w["spread"])))
    var dir := (-basis.z + basis.x * randf_range(-1.0, 1.0) * spread + basis.y * randf_range(-1.0, 1.0) * spread).normalized()
    var from := cam.global_position + dir * cam.global_position.distance_to(chest)
    var to := from + dir * float(w["range"])
    var query := PhysicsRayQueryParameters3D.create(from, to, 3)
    query.exclude = [player.get_rid()]
    var hit := player.get_world_3d().direct_space_state.intersect_ray(query)
    var end := to
    if not hit.is_empty():
        end = hit["position"]
        var target: Object = hit["collider"]
        var dmg := float(w["damage"])
        if target.has_method("apply_damage"):
            if end.y - (target as Node3D).global_position.y > 1.5:
                dmg *= 2.5 # tiro na cabeça
            target.apply_damage(dmg, player.global_position, "bullet", player)
        elif target.has_method("take_damage"):
            target.take_damage(dmg * 0.8)
        _spark(end)
    _tracer(_muzzle(), end)


func _spark(pos: Vector3) -> void:
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.08
    sphere.height = 0.16
    mesh.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.8, 0.3)
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh.material_override = mat
    player.get_parent().add_child(mesh)
    mesh.global_position = pos
    get_tree().create_timer(0.1).timeout.connect(mesh.queue_free)


func _tracer(from: Vector3, to: Vector3) -> void:
    var length := from.distance_to(to)
    if length < 0.3:
        return
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(0.025, 0.025, length)
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.9, 0.5)
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh.material_override = mat
    player.get_parent().add_child(mesh)
    mesh.global_position = (from + to) * 0.5
    var dir := (to - from).normalized()
    var up := Vector3.RIGHT if absf(dir.y) > 0.99 else Vector3.UP
    mesh.look_at(to, up)
    get_tree().create_timer(0.05).timeout.connect(mesh.queue_free)


func throw_grenade() -> void:
    if grenades <= 0 or _cooldown > 0.0:
        return
    grenades -= 1
    _cooldown = 0.8
    _attack_dur = 0.4
    _attack_t = _attack_dur
    var cam: Camera3D = player.get_camera()
    var dir := (-cam.global_transform.basis.z + Vector3.UP * 0.35).normalized()
    var grenade := GrenadeScript.new()
    grenade.thrower = player
    player.get_parent().add_child(grenade)
    grenade.global_position = player.global_position + Vector3(0.0, 1.5, 0.0) + dir * 0.6
    grenade.linear_velocity = dir * 14.0
    _recent_fire = 1.0
    _alarm(25.0)
    _emit_info()


func _launch_rocket(w: Dictionary) -> void:
    var a: Dictionary = _ammo[w["id"]]
    if int(a["mag"]) <= 0:
        if int(a["reserve"]) > 0:
            reload()
        return
    a["mag"] = int(a["mag"]) - 1
    _cooldown = float(w["cooldown"])
    _recent_fire = 1.5
    var cam: Camera3D = player.get_camera()
    var dir := -cam.global_transform.basis.z
    var rocket := GrenadeScript.new()
    rocket.rocket = true
    rocket.radius = 7.0
    rocket.damage = float(w["damage"])
    rocket.thrower = player
    player.get_parent().add_child(rocket)
    rocket.global_position = player.global_position + Vector3(0.0, 1.5, 0.0) + dir * 1.2
    rocket.look_at(rocket.global_position + dir, Vector3.UP)
    rocket.linear_velocity = dir * 38.0
    SfxScript.play_noise(player, 0.35, -2.0, 70.0)
    _alarm(40.0)
    _emit_info()
