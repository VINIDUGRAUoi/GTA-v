extends RigidBody3D
## Granada (explode após 3 s, quica) ou foguete da bazuca (rocket = true: explode ao tocar
## em algo). Criada pelo sistema de combate.

const ExplosionScript := preload("res://scripts/combat/explosion.gd")

var rocket := false
var fuse := 3.0
var radius := 8.0
var damage := 150.0
var thrower: Node3D

var _life := 0.0
var _done := false


func _ready() -> void:
    mass = 0.5
    var shape := CollisionShape3D.new()
    var sph := SphereShape3D.new()
    sph.radius = 0.2 if rocket else 0.12
    shape.shape = sph
    add_child(shape)
    var mesh := MeshInstance3D.new()
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.25, 0.3, 0.15)
    if rocket:
        var box := BoxMesh.new()
        box.size = Vector3(0.14, 0.14, 0.7)
        mesh.mesh = box
        gravity_scale = 0.0
        continuous_cd = true
        contact_monitor = true
        max_contacts_reported = 2
        body_entered.connect(func(_b: Node) -> void: explode())
    else:
        var ball := SphereMesh.new()
        ball.radius = 0.1
        ball.height = 0.2
        mesh.mesh = ball
        var bounce := PhysicsMaterial.new()
        bounce.bounce = 0.35
        bounce.friction = 0.8
        physics_material_override = bounce
    mesh.material_override = mat
    add_child(mesh)
    if thrower != null:
        add_collision_exception_with(thrower)


func _physics_process(delta: float) -> void:
    _life += delta
    if rocket:
        if _life > 5.0:
            explode()
    else:
        fuse -= delta
        if fuse <= 0.0:
            explode()


func explode() -> void:
    if _done:
        return
    _done = true
    ExplosionScript.create(get_parent(), global_position, radius, damage, thrower)
    queue_free()
