extends RefCounted
## Explosão: bola de fogo, luz, fumaça, som e dano em área (pedestres, veículos, jogador).

const SfxScript := preload("res://scripts/core/sfx.gd")


static func create(parent: Node, pos: Vector3, radius: float, damage: float, source: Node3D = null) -> void:
    if parent == null or not parent.is_inside_tree():
        return
    var tree := parent.get_tree()

    # ---- efeitos
    var fx := Node3D.new()
    parent.add_child(fx)
    fx.global_position = pos
    var ball := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 1.0
    sphere.height = 2.0
    ball.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.55, 0.1, 0.75)
    mat.emission_enabled = true
    mat.emission = Color(1.0, 0.45, 0.05)
    mat.emission_energy_multiplier = 2.0
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ball.material_override = mat
    ball.scale = Vector3.ONE * 0.3
    fx.add_child(ball)
    var light := OmniLight3D.new()
    light.light_energy = 6.0
    light.omni_range = radius * 2.5
    fx.add_child(light)
    var smoke := CPUParticles3D.new()
    smoke.amount = 24
    smoke.lifetime = 1.1
    smoke.one_shot = true
    smoke.explosiveness = 1.0
    smoke.direction = Vector3.UP
    smoke.spread = 180.0
    smoke.initial_velocity_min = 3.0
    smoke.initial_velocity_max = 8.0
    smoke.gravity = Vector3(0.0, -4.0, 0.0)
    smoke.scale_amount_min = 0.6
    smoke.scale_amount_max = 1.6
    var puff := SphereMesh.new()
    puff.radius = 0.3
    puff.height = 0.6
    var smoke_mat := StandardMaterial3D.new()
    smoke_mat.albedo_color = Color(0.15, 0.15, 0.15)
    smoke_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    puff.material = smoke_mat
    smoke.mesh = puff
    fx.add_child(smoke)
    smoke.emitting = true
    var tween := fx.create_tween()
    tween.tween_property(ball, "scale", Vector3.ONE * radius * 0.6, 0.3)
    tween.parallel().tween_property(light, "light_energy", 0.0, 0.4)
    tween.tween_callback(ball.queue_free)
    tree.create_timer(1.6).timeout.connect(fx.queue_free)
    SfxScript.play_noise(fx, 0.9, 0.0, 55.0)

    # ---- dano em área
    for ped in tree.get_nodes_in_group("pedestrians"):
        var d: float = ped.global_position.distance_to(pos)
        if d < radius and ped.has_method("apply_damage"):
            ped.apply_damage(damage * (1.0 - d / radius), pos, "explosion", source)
        elif d < radius * 3.0 and ped.has_method("alarm"):
            ped.alarm(pos)
    for v in tree.get_nodes_in_group("vehicles"):
        var d: float = v.global_position.distance_to(pos)
        if d < radius:
            if v is RigidBody3D:
                var away: Vector3 = (v.global_position - pos).normalized() + Vector3.UP * 0.5
                v.apply_central_impulse(away.normalized() * v.mass * 6.0 * (1.0 - d / radius))
            if v.has_method("take_damage"):
                v.take_damage(damage * (1.0 - d / radius) * 0.8)
    for v in tree.get_nodes_in_group("traffic"):
        var d: float = v.global_position.distance_to(pos)
        if d < radius and v.has_method("take_damage"):
            v.take_damage(damage * (1.0 - d / radius) * 0.8)
    for p in tree.get_nodes_in_group("player"):
        var d: float = p.global_position.distance_to(pos)
        if d < radius and p.has_method("take_damage"):
            p.take_damage(damage * 0.5 * (1.0 - d / radius))
