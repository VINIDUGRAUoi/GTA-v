# Arquitetura

## Escolha do motor: Godot 4
- **Gratuito e de código aberto**, sem royalties; o projeto inteiro é texto (GDScript, .tscn), então é versionável e gerável por ferramentas como esta.
- Leve: abre e roda em máquinas modestas e exporta para Windows, Linux, Android e outros.
- Unreal 5 daria gráficos melhores, mas exige hardware e conhecimento pesados e projetos binários (.uasset) que não dá para escrever como texto. Unity exigiria C# e licenciamento.
- Limite honesto: Godot não alcança o nível gráfico de um AAA; o foco é jogabilidade e sistemas.

## Princípios
- Cada sistema numa pasta própria, comunicando-se por **sinais** (ex.: o HUD só recebe `health_changed`).
- Dados (veículos, missões) em `data/` como Resources/JSON, para adicionar conteúdo sem mexer no código.
- Placeholders gerados em código até haver arte real; sempre identificados como tal.

## Pastas
```
project.godot          configuração e autoload InputSetup
scenes/main.tscn       cena de entrada (apenas liga scripts/main.gd)
scripts/main.gd        monta mundo, HUD e jogador
scripts/core/          entrada e (futuro) estado do jogo, configurações
scripts/player/        personagem 3ª pessoa, câmera, vida e resistência
scripts/world/         geração da cidade
scripts/ui/            HUD (futuro: menus, mapa, GPS)
scripts/vehicles/      (Etapa 4) VehicleBody3D, garagem
scripts/ai/            (Etapa 6) pedestres, trânsito, polícia por máquina de estados
scripts/missions/      (Etapa 7) missões como Resources + gerenciador
scripts/save/          (Etapa 8) salvar/carregar em JSON
data/                  (futuro) definições de veículos e missões
tests/run_tests.gd     testes headless
```

## Plano por etapa
1. Motor e arquitetura — **feito (este documento)**
2. Projeto executável e controles — escrito, **não testado**
3. Personagem, câmera, colisões — escrito, **não testado**
4. Veículos (VehicleBody3D) — pendente
5. Cidade — versão inicial (grade de quarteirões) escrita, **não testada**
6–10. Pendentes
