# Como adicionar conteúdo

## Novo veículo
1. Abra `scripts/vehicles/vehicle_data.gd`.
2. Copie uma entrada de `TYPES`, dê um id novo (ex.: `"taxi"`) e ajuste massa, potência, tamanho e cores.
3. Adicione o id na lista `IDS` para ele aparecer no trânsito.
4. Para estacionar um perto do início, adicione uma linha em `PARKED` no `scripts/main.gd`.
Ele já é dirigível e entrável automaticamente.

## Ajuste de direção
Se um carro andar **para trás** ao acelerar, mude `ENGINE_SIGN` para `-1.0` em `scripts/vehicles/vehicle.gd`.

## Brasileiros nas ruas
Os veículos usam formas e pinturas comuns no Brasil (hatch compacto, sedã médio, picapes, van clássica, táxi, viatura, ambulância, ônibus), sem logotipos nem nomes de marcas. A lista TRAFFIC_MIX em `vehicle_data.gd` controla a frequência de cada tipo no trânsito e nos carros estacionados.

## Armas
Edite a lista WEAPONS em `scripts/combat/combat.gd` (dano, cadência, dispersão, munição). Para o visual na mão, adicione o id em HELD.

## Novas missões
O sistema de missões ainda não existe (Etapa 7).
