# Registro de estado (atualizado a cada etapa)

## Escrito, mas NÃO executado (sem Godot no ambiente de geração)
- Entrada configurável (teclado + gamepad) via autoload
- Jogador: andar, correr com resistência, pular, agachar (com checagem de teto), câmera 3ª pessoa com SpringArm (não atravessa paredes), vida, cura, respawn, queda no vazio
- HUD com vida, resistência, FPS e dicas
- Cidade de 36 quarteirões (praças aleatórias, prédios com colisão), avenidas, rampa e caixas de teste, sol com sombras e céu procedural
- Testes headless (`tests/run_tests.gd`)
- Controles de toque para Android (analógico flutuante, arrastar para a câmera, botões Pular/Correr/Agachar/Usar), HUD ampliado e sombras desligadas em celular
- Preset de exportação Android e fluxo do GitHub Actions (`.github/workflows/build.yml`), que também roda os testes na nuvem

## Testes realizados
Nenhum. Nada foi compilado nem executado. Podem existir erros de sintaxe ou de API do Godot; o primeiro passo é abrir o projeto e me enviar a saída do editor.

## Limitações conhecidas
- Visuais são caixas e cápsulas coloridas; sem animação de personagem
- Sem degraus automáticos (só rampas e saltos até ~1,5 m)
- Sem interiores, NPCs, veículos, polícia, missões, menus, mapa, salvamento, áudio, ciclo dia/noite ou clima
- Cidade pequena (~310 m de lado), todos os nós carregados de uma vez; sem LOD nem streaming ainda
- `interact` só emite um sinal; nada o consome ainda

## Próximo passo
Etapa 4: veículo dirigível (VehicleBody3D), entrar/sair e câmera de veículo.
