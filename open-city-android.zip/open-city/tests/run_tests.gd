extends SceneTree
## Testes headless simples (sem dependências externas).
## Execute:  godot --headless --path . -s tests/run_tests.gd
## Código de saída 0 = tudo certo, 1 = alguma falha.

const InputScript := preload("res://scripts/core/input_setup.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const WorldScript := preload("res://scripts/world/world_builder.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const PedScript := preload("res://scripts/ai/pedestrian.gd")
const TrafficScript := preload("res://scripts/ai/traffic_car.gd")

var _failures := 0


func _initialize() -> void:
    _test_input_actions()
    _test_player_health()
    _test_world_builder()
    _test_city_graph()
    _test_vehicle_data()
    _test_vehicle()
    _test_npcs()
    print("Resultado: ", "TUDO OK" if _failures == 0 else "%d falha(s)" % _failures)
    quit(1 if _failures > 0 else 0)


func _check(condition: bool, label: String) -> void:
    if condition:
        print("  [ok]    ", label)
    else:
        print("  [FALHA] ", label)
        _failures += 1


func _test_input_actions() -> void:
    print("Entrada")
    InputScript.register()
    InputScript.register() # idempotência
    for action in ["move_forward", "move_back", "move_left", "move_right", "jump", "sprint", "crouch", "interact", "pause", "map", "look_left"]:
        _check(InputMap.has_action(action), "ação registrada: " + action)
    _check(InputMap.action_get_events("jump").size() == 2, "jump tem teclado + gamepad sem duplicar")


func _test_player_health() -> void:
    print("Jogador")
    var player := PlayerScript.new()
    player.spawn_position = Vector3(0.0, 0.1, 0.0)
    root.add_child(player)
    var deaths := [0]
    player.died.connect(func() -> void: deaths[0] += 1)

    player.take_damage(30.0)
    _check(is_equal_approx(player.health, 70.0), "dano reduz a vida")
    player.take_damage(-5.0)
    _check(is_equal_approx(player.health, 70.0), "dano negativo é ignorado")
    player.heal(1000.0)
    _check(is_equal_approx(player.health, player.max_health), "cura respeita o máximo")
    player.take_damage(1000.0)
    _check(deaths[0] == 1, "morte emite sinal uma vez")
    _check(is_equal_approx(player.health, player.max_health), "respawn restaura a vida")
    player.queue_free()


func _test_world_builder() -> void:
    print("Mundo")
    var world := WorldScript.new()
    root.add_child(world)
    world.build()
    var side := WorldScript.GRID_MAX - WorldScript.GRID_MIN + 1
    var blocks := side * side
    _check(world.building_count > 0, "gera prédios")
    _check(world.building_count == (blocks - world.park_count) * 4, "4 prédios por quarteirão não-praça")
    _check(world.building_rects.size() == world.building_count, "dados do mapa: um retângulo por prédio")
    _check(world.park_rects.size() == world.park_count, "dados do mapa: um retângulo por praça")
    var again := WorldScript.new()
    root.add_child(again)
    again.build()
    _check(again.building_count == world.building_count, "geração é determinística")
    world.queue_free()
    again.queue_free()


func _test_city_graph() -> void:
    print("Grafo da cidade")
    _check(WorldScript.BLOCK_SIZE + WorldScript.ROAD_WIDTH == GraphScript.PITCH, "constantes batem com o world_builder")
    var ok := true
    for i in range(GraphScript.BLOCK_MIN, GraphScript.BLOCK_MAX + 1):
        for j in range(GraphScript.BLOCK_MIN, GraphScript.BLOCK_MAX + 1):
            for c in 4:
                var neighbors := GraphScript.ped_neighbors(i, j, c)
                if neighbors.size() < 2:
                    ok = false
                for n: Vector3i in neighbors:
                    if not GraphScript.block_in_range(n.x, n.y):
                        ok = false
    _check(ok, "todo canto de calçada tem vizinhos válidos")
    var a := GraphScript.ped_corner_pos(0, 0, 1)
    var cross := GraphScript.ped_neighbors(0, 0, 1)
    var crossing_ok := false
    for n: Vector3i in cross:
        if n.x != 0 or n.y != 0:
            var b := GraphScript.ped_corner_pos(n.x, n.y, n.z)
            crossing_ok = absf(a.distance_to(b) - 7.0) < 0.01
    _check(crossing_ok, "travessia de rua tem 7 m")
    var route := GraphScript.route(Vector2(5.0, 5.0), Vector2(-100.0, 90.0))
    _check(route.size() == 7, "rota do GPS tem 7 pontos")
    _check(route[0] == Vector2(5.0, 5.0) and route[6] == Vector2(-100.0, 90.0), "rota começa e termina nos pontos pedidos")
    var starts := GraphScript.traffic_starts_in_range(Vector3.ZERO, 0.0, 400.0)
    _check(starts.size() == 2 * 7 * 6 * 2, "trechos de via: 168 (7x6 em cada eixo, 2 sentidos)")


func _test_vehicle_data() -> void:
    print("Dados dos veículos")
    for id: String in DataScript.IDS:
        var d: Dictionary = DataScript.TYPES[id]
        var complete := true
        for key in ["name", "mass", "power", "awd", "max_speed", "steer", "size", "cabin", "cabin_z", "wheel_radius", "suspension", "colors"]:
            if not d.has(key):
                complete = false
        _check(complete, "tipo completo: " + id)


func _test_vehicle() -> void:
    print("Veículo")
    var vehicle = FactoryScript.create("sedan")
    root.add_child(vehicle)
    var wheels := 0
    for child in vehicle.get_children():
        if child is VehicleWheel3D:
            wheels += 1
    _check(wheels == 4, "tem 4 rodas")
    _check(vehicle.is_in_group("enterable") and vehicle.is_in_group("vehicles"), "está nos grupos enterable/vehicles")
    _check(vehicle.can_enter(), "livre pode ser ocupado")
    var player := PlayerScript.new()
    root.add_child(player)
    vehicle.set_driver(player)
    _check(not vehicle.can_enter(), "ocupado não pode ser ocupado de novo")
    vehicle.clear_driver()
    _check(vehicle.can_enter(), "libera ao sair")
    var unknown = FactoryScript.create("tipo_inexistente")
    root.add_child(unknown)
    _check(unknown.type_id == "sedan", "tipo desconhecido vira sedan")
    vehicle.queue_free()
    unknown.queue_free()
    player.queue_free()


func _test_npcs() -> void:
    print("NPCs")
    var ped = PedScript.new()
    ped.place(Vector3i(0, 0, 0))
    root.add_child(ped)
    _check(ped.target != Vector3.ZERO, "pedestre escolhe um destino")
    ped.queue_free()
    var car = TrafficScript.new()
    car.setup("suv", Color(0.2, 0.2, 0.2))
    car.start(0, 0, Vector2i(1, 0))
    root.add_child(car)
    _check(car.can_enter() and car.get_display_name() == "SUV", "carro do trânsito é entrável")
    car.queue_free()
