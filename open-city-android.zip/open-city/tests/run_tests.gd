extends SceneTree
## Testes headless simples (sem dependências externas).
## Execute:  godot --headless --path . -s tests/run_tests.gd
## Código de saída 0 = tudo certo, 1 = alguma falha.

const InputSetup := preload("res://scripts/core/input_setup.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const WorldBuilder := preload("res://scripts/world/world_builder.gd")

var _failures := 0


func _initialize() -> void:
    _test_input_actions()
    _test_player_health()
    _test_world_builder()
    print("Resultado: ", "TUDO OK" if _failures == 0 else "%d falha(s)" % _failures)
    quit(1 if _failures > 0 else 0)


func _check(condition: bool, name: String) -> void:
    if condition:
        print("  [ok]    ", name)
    else:
        print("  [FALHA] ", name)
        _failures += 1


func _test_input_actions() -> void:
    print("Entrada")
    InputSetup.register()
    InputSetup.register() # idempotência
    for action in ["move_forward", "move_back", "move_left", "move_right", "jump", "sprint", "crouch", "interact", "pause", "look_left"]:
        _check(InputMap.has_action(action), "ação registrada: " + action)
    _check(InputMap.action_get_events("jump").size() == 2, "jump tem teclado + gamepad sem duplicar")


func _test_player_health() -> void:
    print("Jogador")
    var player := PlayerScript.new()
    player.spawn_position = Vector3(0.0, 0.1, 0.0)
    root.add_child(player)
    var deaths := [0]
    player.died.connect(func() -> void: deaths[0] += 1)

    player.take_damage(30.0)
    _check(is_equal_approx(player.health, 70.0), "dano reduz a vida")
    player.take_damage(-5.0)
    _check(is_equal_approx(player.health, 70.0), "dano negativo é ignorado")
    player.heal(1000.0)
    _check(is_equal_approx(player.health, player.max_health), "cura respeita o máximo")
    player.take_damage(1000.0)
    _check(deaths[0] == 1, "morte emite sinal uma vez")
    _check(is_equal_approx(player.health, player.max_health), "respawn restaura a vida")
    player.queue_free()


func _test_world_builder() -> void:
    print("Mundo")
    var world := WorldBuilder.new()
    root.add_child(world)
    world.build()
    var blocks := (WorldBuilder.GRID_MAX - WorldBuilder.GRID_MIN + 1) * (WorldBuilder.GRID_MAX - WorldBuilder.GRID_MIN + 1)
    _check(world.building_count > 0, "gera prédios")
    _check(world.building_count == (blocks - world.park_count) * 4, "4 prédios por quarteirão não-praça")
    var again := WorldBuilder.new()
    root.add_child(again)
    again.build()
    _check(again.building_count == world.building_count, "geração é determinística")
    world.queue_free()
    again.queue_free()
